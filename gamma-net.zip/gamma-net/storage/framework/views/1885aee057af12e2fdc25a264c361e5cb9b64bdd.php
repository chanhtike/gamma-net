<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
 			
 			<div class="col-md-9">
                <h2>User Guide Book Download</h2>
                <p>Click the following image to download latest user guide book for Gamma-Net</p>
               <a href="download/user-guide.pdf"><img src="img/guide.png" style="max-width:80%;"> </a>
                <p>Thank's for using our services</p>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>