<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
    @parent
            
            <div class="col-md-9">
                <h2>Are you sure to buy this topup card</h2>
               <p>Your preferred Telecom : <b>Telenor</b></p>
                <p>Your Preferred Amount : <b>10000-MMK</b></p>
                <form role="form" action="member-topup-success">
                    <div class="checkbox">
                        <label><input type="checkbox"> All data I've chosen above are Right!</label>
                    </div>
                     <button type="submit" class="btn btn-default">Confirm</button>
                </form>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>