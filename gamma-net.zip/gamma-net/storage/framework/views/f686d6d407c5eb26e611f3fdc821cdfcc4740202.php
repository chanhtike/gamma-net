<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
       
 			
 			<div class="col-md-9">
                <h2>Cash Deposit</h2>
                <p>You can now deposit cash to user A/C:</p>
                <form role="form" action="#">
                	<div class="form-group">
                        <label for="user-id">User ID :</label>
                        <input type="text" class="form-control" id="user-id" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="user-name">User Name:</label>
                        <input type="text" class="form-control" id="user-name" style="max-width:300px;">
                    </div>
                    <button type="button" class="btn btn-default">Search</button>
                    <hr>
                    
                    <div class="form-group">
                        <label for="dep-amt">Deposit Amount:</label>
                        <input type="text" class="form-control" id="dep-amt" style="max-width:300px;">
                    </div>
                        <button type="submit" class="btn btn-default">Insert</button>
                    <hr>

                    
                    
                </form>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>