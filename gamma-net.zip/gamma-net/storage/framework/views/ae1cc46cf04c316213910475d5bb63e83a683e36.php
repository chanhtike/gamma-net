<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
         			
 			<div class="col-md-9">
                <h2>Insert Ph Bill</h2>
                <p>Insert New Phone Bill Card</p>
                <form role="form" action="cash-in-success">
                	<div class="form-group">
                        <label for="telecom">Telecom :</label>
                        <input type="text" class="form-control" id="telecom" style="max-width:300px;">
                    </div>                        
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control" id="name" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="price">Price:</label>
                        <input type="text" class="form-control" id="price" style="max-width:300px;">   
                    </div>
                    <div class="form-group">
                        <label for="code">New Code:</label>
                        <input type="text" class="form-control" id="code" style="max-width:300px;">   
                    </div>
                     <button type="submit" class="btn btn-default">Insert</button>
                </form>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.cashier-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>