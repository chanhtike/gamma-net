<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
         			
 			<div class="col-md-9">
                <h2>View Products</h2>
                <p>View Products by name</p>
                <form role="form" action="cash-in-success">
                	<div class="form-group">
                        <label for="p-name">Product Name :</label>
                        <input type="text" class="form-control" id="p-name" style="max-width:300px;">
                    </div>                        
                    <button type="submit" class="btn btn-default">Search</button>
                     <div style="width:95%; height:100%; overflow:auto; padding:5px;">
                <div class="transitions" style="width: 800px; height:300px;">
                    <table>
                    <tr>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Color</th>
                        <th>Size</th>
                        <th>Amount</th>
                        <th>Price</th>                 
                    </tr> 
                    <tr>
                        <td>Long Pant 123</td>
                        <td>Men Pant</td>
                        <td>Grey</td>
                        <td>L</td>
                        <td>2</td>
                        <td>20,000</td>                         
                    </tr>       
                    </table>         
                </div>
                </div>
               
                </form>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.cashier-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>