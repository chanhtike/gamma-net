<?php $__env->startSection('title', 'Page Title'); ?>
<?php $__env->startSection('sidebar'); ?>
		@parent
		<p>This is appended to the master sidebar-2222.</p>
	<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
		<h2><?php echo e($name); ?></h2>
		<p>This is my body content-2222.</p>
	<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>