<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
       
 			
 			<div class="col-md-9">
                <h2>End of Month</h2>
                <p>Run End of Month if you sure to close monthly:</p>
                <form role="form" action="#">
                	
                        <button type="submit" class="btn btn-default">Confirm</button>
                    <hr>

                    
                    
                </form>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>