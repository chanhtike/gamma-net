<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
    @parent
    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">ေစ်းဝယ္ထြက္မယ္
                    <small>Happy Shopping!!</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="mm-index">Home</a>
                    </li>
                    <li class="active">Online Shopping</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Projects Row -->
        <div class="row">
            <div class="col-md-6 img-portfolio">
                <a href="mm-product-list">
                    <img class="img-responsive img-hover" src="img/clothing.jpg" alt="">
                </a>
                <h3>
                    <a href="mm-product-list">အဝတ္အထည္မ်ား</a>
                </h3>
                <p>က်ားဝတ္၊ မဝတ္ ႏွင့္ ကေလးအဝတ္မ်ိဳးစံု ပိတ္စမ်ိဳးစံုႏွင့္ မိုးကာ၊ ထီး၊ ဖိနပ္ စသည္ ….</p>
            </div>
            <div class="col-md-6 img-portfolio">
                <a href="mm-product-list">
                    <img class="img-responsive img-hover" src="img/phone.jpg" alt="">
                </a>
                <h3>
                    <a href="mm-product-list">ဖုန္းႏွင့္အပိုပစၥည္းမ်ား</a>
                </h3>
                <p>ဖုန္းဟမ္းဆက္မ်ိဳးစံု၊ ကာဗာမ်ိဳးစံု၊ အျခားအပိုပစၥည္းႏွင့္ ဖုန္းအလွဆင္ပစၥည္းမ်ား စသည္ ….</p>
            </div>
        </div>
        <!-- /.row -->

        <!-- Projects Row -->
        <div class="row">
            <div class="col-md-6 img-portfolio">
                <a href="mm-product-list">
                    <img class="img-responsive img-hover" src="img/cosmetics.jpg" alt="">
                </a>
                <h3>
                    <a href="mm-product-list">အလွကုန္</a>
                </h3>
                <p>အမ်ိဳးသား ႏွင့္ အမ်ိဳးသမီးသံုး ေရေမႊး၊ မ်က္ႏွာလိမ္းကရင္၊ Body Lotion၊ မိတ္ကပ္ စသည္ ….</p>
            </div>
            <div class="col-md-6 img-portfolio">
                <a href="mm-product-list">
                    <img class="img-responsive img-hover" src="img/electronics.jpg" alt="">
                </a>
                <h3>
                    <a href="mm-product-list">လွ်ပ္စစ္ပစၥည္းမ်ား</a>
                </h3>
                <p>တီဗြီ၊ ေရခဲေသတၱာ၊ အဝတ္ေလွ်ာ္စက္မွစ၍ လွ်ပ္စစ္  မီးသီး မီးလံုး ႏွင့္ အျခား ပစၥည္းမ်ား ….</p>
            </div>
        </div>
        <!-- /.row -->

        <!-- Projects Row -->
        <div class="row">
            <div class="col-md-6 img-portfolio">
                <a href="mm-product-list">
                    <img class="img-responsive img-hover" src="img/computer.jpg" alt="">
                </a>
                <h3>
                    <a href="mm-product-list">ကြန္ပ်ဴတာႏွင့္ရံုးသံုး</a>
                </h3>
                <p>ကြန္ပ်ဴတာႏွင့္ ကြန္ပ်ဴတာ အပိုပစၥည္းမ်ား၊ Memory Stick၊ Speaker မ်ားႏွင့္ အျခား ….</p>
            </div>
            <div class="col-md-6 img-portfolio">
                <a href="mm-product-list">
                    <img class="img-responsive img-hover" src="img/foods.jpg" alt="">
                </a>
                <h3>
                    <a href="mm-product-list">အစားအစာမ်ား</a>
                </h3>
                <p>ျမန္မာ့ရိုးရာအစားအစာမ်ား၊ အေနာက္တိုင္းအစားအစာမ်ား၊ ပင္လယ္စာ ႏွင့္ အျခားအစားအစာမ်ား ….</p>
            </div>
        </div>
        <!-- /.row -->

        <hr>

        <!-- Pagination -->
        <div class="row text-center">
            <div class="col-lg-12">
                <ul class="pagination">
                    <li>
                        <a href="#">&laquo;</a>
                    </li>
                    <li class="active">
                        <a href="#">1</a>
                    </li>
                    <li>
                        <a href="#">2</a>
                    </li>
                    <li>
                        <a href="#">3</a>
                    </li>
                    <li>
                        <a href="#">4</a>
                    </li>
                    <li>
                        <a href="#">5</a>
                    </li>
                    <li>
                        <a href="#">&raquo;</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- /.row -->

        <hr>

        <!-- Footer -->
        <?php $__env->stopSection(); ?>
        <!-- Footer -->
<?php $__env->startSection('footer'); ?>
    
@parent

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mm-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>