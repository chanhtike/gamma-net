<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
         			
 			<div class="col-md-9">
                <h2>View Cash In Hand</h2>
                <p>View Cash In Hand of sold products!</p>
                <form role="form" action="cash-in-success">
                	<div class="form-group">
                        <label for="cash-inhand">Cash In Hand :</label>
                        <input type="text" class="form-control" id="cash-inhand" style="max-width:300px;">MMK
                    </div>                        
                    <div class="form-group">
                        <label for="withdrawl-amt">Withdrawl Amount :</label>
                        <input type="text" class="form-control" id="withdrawl-amt" style="max-width:300px;">MMK
                    </div>
                  
                     <button type="button" class="btn btn-default">Confirm</button>
                </form>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.cashier-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>