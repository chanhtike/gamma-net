<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
 			
 			<div class="col-md-9">
                <h2>Money transfer process successful!</h2>
                <p>Cash- <b>xxx</b>Ks will be transmitted to <b>xxx</b> in 15 minutes</p>
                <p>Your remaining balance is - xxx Kyats</p>
                <p>Thanks for using our services</p>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>