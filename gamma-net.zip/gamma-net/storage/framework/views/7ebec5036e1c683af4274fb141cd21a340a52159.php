<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
    @parent
                <script language="JavaScript">
                function show()
                {
                    
                    var a="1";
                    if(a=="1")
                    {
                        document.getElementById("prepaid").style.display="block";
                    }
                    else
                    {
                        document.getElementById("product").style.display="block";
                    }
                }
                
                </script>

            <div class="col-md-9">
                <h2>Monthly Mark</h2>
                <p>You can make monthly mark here, monthly mark for this month is :</p>
               <form role="form" action="#">
                 <input type="button" onclick="show()" value="Show Mark"/>   
                 <br>
                <div id="prepaid" style="display:none">
                   <p>Buy Phone Bill <br>
                   Cost : <b>10,000</b></p>
                </div>

                    
                <div id="product" style="display:none">
                    <p>Buy Product
                     <br>
                   Cost : <b>10,000</b></p>
                </div>
                <hr>


                 
                     <button type="submit" class="btn btn-default">Mark Now</button>
                </form>
            </div>
               
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>