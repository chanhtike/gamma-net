<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
    
         
 			<div class="col-md-9" >
                <h2>Cash Out Requests</h2>
                <h3>Please confirm the following requests</h3>
                
               
                                 
                
                <div style="width:95%; height:100%; overflow:auto; padding:5px;">
                <div class="transitions" style="width: 800px; height:300px;">
                    <table>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>User-Id</th>
                        <th>User-name</th>
                        <th>Bank</th>
                        <th>Bank-A/C</th>
                        <th>A/C Number</th>
                        <th>A/C Name</th>
                        <th>Amount</th>
                        <th>Phone</th>
                        <th>
                         Confirm
                        </th>
                        <th>
                          Cancel
                        </th>                
                    </tr> 
                    <tr>
                        <th>8.2.2017</th>
                        <th>9:02 AM</th>
                        <th>GN-0003</th>
                        <th>Chan Chan</th>
                        <th>AYA</th>
                        <th>0041201010001234</th>
                        <th>A/C Number</th>
                        <th>Daw Chan Chan</th>
                        <th>70,000</th>
                        <th>09-12345678</th>
                        <th>
                          <button type="button">Confirm</button>
                        </th>
                        <th>
                          <button type="button">Cancel</button>
                        </th>  
                    </tr>
                      <tr>
                        <th>8.2.2017</th>
                        <th>9:02 AM</th>
                        <th>GN-0003</th>
                        <th>Moe Moe</th>
                        <th>KBZ</th>
                        <th>0041201010005432</th>
                        <th>A/C Number</th>
                        <th>Daw Moe Moe</th>
                        <th>70,000</th>
                        <th>09-12345678</th>
                        <th>
                          <button type="button">Confirm</button>
                        </th>
                        <th>
                          <button type="button">Cancel</button>
                        </th>   
                    </tr>             
                    </table>         
                </div>
                </div>
               
            </div>

           


    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>