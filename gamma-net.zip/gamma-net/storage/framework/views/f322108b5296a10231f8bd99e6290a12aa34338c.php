<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
 			
 			<div class="col-md-9">
                <h2>ေငြလႊဲပို႔မည့္အခ်က္အလက္မ်ား ေသခ်ာေအာင္စစ္ေဆးပါ</h2>
                <p>ပို႔သူအမည္  -<b>xxxx</b></p>
                <p>လက္ခံသူအမည္ -<b>xxxx</b></p>
                <p>ေငြပမာဏ -<b>xxxx</b></p>
                <div class="checkbox">
                        <label><input type="checkbox">အထက္ပါအခ်က္အလက္မ်ားမွန္ကန္ပါသည္</label>
                    </div>
                    <a href="mm-remit-success" class="btn btn-primary">လႊဲပို႔မည္</a>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mm-member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>