<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
    
         
 			<div class="col-md-9" >
                <h2>Remit to Gamma-Net A/C Requests</h2>
                <h3>Please confirm the following requests</h3>
                
               
                                 
                
                <div style="width:95%; height:100%; overflow:auto; padding:5px;">
                <div class="transitions" style="width: 800px; height:300px;">
                    <table>
                    <tr>
                        <th>User-ID</th>
                        <th>User-name</th>
                        <th>A/C</th>
                        <th>Receiver Name</th>
                        <th>Receiver NRC</th>
                        <th>Remit Amt</th>
                        <th>Charges</th>
                        <th>Total</th>
                        <th>
                         Confirm
                        </th>
                        <th>
                          Cancel
                        </th>                
                    </tr> 
                    <tr>
                        <th>GN-0012</th>
                        <th>Kyaw Kyaw</th>
                        <th>GN-0236</th>
                        <th>Oo Oo</th>
                        <th>11/TKK(N) 654321</th>
                        <th>09-1234567</th>
                        <th>200,000</th>
                        <th>2000</th>
                        <th>202,000</th>
                        <th>
                          <button type="button">Confirm</button>
                        </th>
                        <th>
                          <button type="button">Cancel</button>
                        </th>               
                    </tr> 
                              
                    </table>         
                </div>
                </div>
               
            </div>

           


    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>