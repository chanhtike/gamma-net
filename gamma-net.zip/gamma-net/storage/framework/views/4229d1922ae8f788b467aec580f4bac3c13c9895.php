<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
 	<script language="JavaScript">
        function hs()
        {
            var a=document.getElementById("wm").value;
            if(a=="Withdrawl to Bank A/C")
            {
                document.getElementById("hs").style.display="block";
            }
            else
            {
                document.getElementById("ac").value="";
                document.getElementById("acname").value="";
                document.getElementById("hs").style.display="none";
            }
        }
    </script>
 			
            <div class="col-md-9">
                <h2>Cash Out</h2>
                <p>You can now withdrawl cash from your Gamma-Net Account</p>
                <form role="form" action="cash-out-success">
                	<div class="form-group">
                        <label for="usr">Email :</label>
                        <input type="text" class="form-control" id="usr" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="usr">Password :</label>
                        <input type="password" class="form-control" id="usr" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="usr">NRC No :</label>
                        <input type="text" class="form-control" id="usr" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="wm">Withdrawl Method :</label>
                            <select class="form-control" id="wm" style="max-width:200px;" onchange="hs()">
                                <option>From Gamma-Net Agent</option>
                                <option>Withdrawl to Bank A/C</option>                                
                            </select>
                    </div>


                    <div id="hs" style="display:none">
                        <div class="form-group">
                            <label for="ac">Bank Account Number :</label>
                            <input type="text" class="form-control" id="ac" style="max-width:300px;">
                        </div>
                        <div class="form-group">
                            <label for="acname">Bank Account Name :</label>
                            <input type="text" class="form-control" id="acname" style="max-width:300px;">
                        </div>
                        <div class="form-group">
                        <label for="sel1">Choose Bank :</label>
                            <select class="form-control" id="sel1" style="max-width:200px;">
                                <option>KBZ</option>
                                <option>AYA</option>
                                <option>CB</option>
                                <option>MAB</option>
                            </select>
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="usr">Cash Amount :</label>
                        <input type="text" class="form-control" id="usr" style="max-width:300px;">
                    </div>
                    <div class="checkbox">
                        <label><input type="checkbox"> I am sure to withdrawl cash from my Gamma-Net A/C.</label>
                    </div>
                     <button type="submit" class="btn btn-default">Confirm</button>
                </form>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>