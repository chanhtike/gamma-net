<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
    @parent
            
            <div class="col-md-9">
                <h2>ဤေငြျဖည့္ကတ္ဒ္ကို ဝယ္ယူရန္ေသခ်ာပါသလား</h2>
               <p>အမ်ိဳးအစား : <b>Telenor</b></p>
                <p>ေငြပမာဏ : <b>10000-MMK</b></p>
                <form role="form" action="mm-member-topup-success">
                    <div class="checkbox">
                        <label><input type="checkbox"> အထက္ပါအခ်က္အလက္မ်ားအားလံုးမွန္ကန္ပါသည္</label>
                    </div>
                     <button type="submit" class="btn btn-default">ဝယ္ရန္ေသခ်ာပါသည္</button>
                </form>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.mm-member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>