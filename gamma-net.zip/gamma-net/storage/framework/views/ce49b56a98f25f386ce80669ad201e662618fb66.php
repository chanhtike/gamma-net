<!DOCTYPE html>
<html lang="en">

<head>
<title><?php echo $__env->yieldContent('title'); ?></title>
<link href="jquery-ui.css" rel="stylesheet">
    <style>
    body{
        font-family: "Trebuchet MS", sans-serif;
        margin: 50px;
    }
    .demoHeaders {
        margin-top: 2em;
    }
    #dialog-link {
        padding: .4em 1em .4em 20px;
        text-decoration: none;
        position: relative;
    }
    #dialog-link span.ui-icon {
        margin: 0 5px 0 0;
        position: absolute;
        left: .2em;
        top: 50%;
        margin-top: -8px;
    }
    #icons {
        margin: 0;
        padding: 0;
    }
    #icons li {
        margin: 2px;
        position: relative;
        padding: 4px 0;
        cursor: pointer;
        float: left;
        list-style: none;
    }
    #icons span.ui-icon {
        float: left;
        margin: 0 4px;
    }
    .fakewindowcontain .ui-widget-overlay {
        position: absolute;
    }
    select {
        width: 200px;
    }
    </style>
<?php $__env->startSection('header'); ?>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Gamma Net Co,.Ltd</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/multilevel-tree.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/modern-business.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
     <link rel="shortcut icon" href="img/gn.ico" />
     
     <link rel="stylesheet" href="css/jquery-ui.css">
 
    <script src="js/jquery.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/jquery-ui.min.js"></script>
</head>
<body>
<?php $__env->startSection('sidebar'); ?>
<nav class="navbar navbar-inverse navbar-fixed-top"  role="navigation">
        <div class="container" >
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header" >
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="mm-index">Gamma Net</a>
                
            </div>
            
            
           

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                
                    <li>
                        <a href="mm-index">ပင္မစာမ်က္ႏွာ</a>
                    </li>
                    <li>
                        <a href="mm-about">ကၽြႏု္ပ္တို႔အေၾကာင္း</a>
                    </li>
                    <li>
                        <a href="mm-services">ဝန္ေဆာင္မႈမ်ား</a>
                    </li>
                    <li>
                        <a href="mm-contact">ဆက္သြယ္ရန္</a>
                    </li>                  
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">အသင္းဝင္စနစ္<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="mm-login-page">ဝင္မည္</a>
                            </li>
                            <li>
                                <a href="mm-reg-page">မွတ္ပံုတင္မည္</a>
                            </li>
                        </ul>
                    </li>
                     <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">ဘာသာစကား<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                            <a href="index">English</a>
                            </li>
                            <li>
                            <a href="mm-index">ျမန္မာ</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <div class="input-group" style="padding-top: 10px; max-width: 300px;">
                            <input type="text" class="form-control" placeholder="Search Gamma-Net..">
                            <span class="input-group-btn">
                             <button class="btn btn-default" type="button">
                                <span class="glyphicon glyphicon-search"></span>
                             </button>
                         </span>
                         </div>
                    </li>
                    <!--<li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Portfolio <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="portfolio-1-col.html">1 Column Portfolio</a>
                            </li>
                            <li>
                                <a href="portfolio-2-col.html">2 Column Portfolio</a>
                            </li>
                            <li>
                                <a href="portfolio-3-col.html">3 Column Portfolio</a>
                            </li>
                            <li>
                                <a href="portfolio-4-col.html">4 Column Portfolio</a>
                            </li>
                            <li>
                                <a href="portfolio-item.html">Single Portfolio Item</a>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Blog <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="blog-home-1.html">Blog Home 1</a>
                            </li>
                            <li>
                                <a href="blog-home-2.html">Blog Home 2</a>
                            </li>
                            <li>
                                <a href="blog-post.html">Blog Post</a>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Other Pages <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="full-width.html">Full Width Page</a>
                            </li>
                            <li>
                                <a href="sidebar.html">Sidebar Page</a>
                            </li>
                            <li>
                                <a href="faq.html">FAQ</a>
                            </li>
                            <li>
                                <a href="404.html">404</a>
                            </li>
                            <li>
                                <a href="pricing.html">Pricing Table</a>
                            </li>
                        </ul>
                    </li>
                    -->
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
<?php echo $__env->yieldSection(); ?>
<?php $__env->startSection('footer'); ?>
<footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; CU Soft Compilation Team</p>
                </div>
            </div>
</footer>
<?php echo $__env->yieldSection(); ?>
</body>
</html>