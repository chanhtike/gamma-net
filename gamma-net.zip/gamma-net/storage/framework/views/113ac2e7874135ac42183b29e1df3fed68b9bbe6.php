<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
    @parent
    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <small>Subheading</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="mm-index">Home</a>
                    </li>
                    <li class="active">Women Dress</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Portfolio Item Row -->
        <div class="row">

            <div class="col-md-8">
                <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                    <!-- Indicators -->
                    <ol class="carousel-indicators">
                        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                        <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                    </ol>

                    <!-- Wrapper for slides -->
                    <div class="carousel-inner">
                        <div class="item active">
                            <img class="img-responsive" src="img/womendress.png" alt="">
                        </div>
                        <div class="item">
                            <img class="img-responsive" src="img/womendress2.png" alt="">
                        </div>
                        <div class="item">
                            <img class="img-responsive" src="img/womendress3.png" alt="">
                        </div>
                    </div>

                    <!-- Controls -->
                    <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                    </a>
                    <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                    </a>
                </div>
            </div>

            <div class="col-md-4">
                <h3>This is our product</h3>
                <p>This product is created from USA. It is really a brand</p>
                <h3>Benefits</h3>
                <ul>
                    <li>Smooth</li>
                    <li>Slim</li>
                    <li>Soft</li>
                    
                </ul>
                <form role="form" action="mm-item-confirm">
                    
                    <div class="form-group">
                        <label for="email">Email address:</label>
                        <input type="email" class="form-control" id="email" style="max-width:300px;">
                    </div>
                    
                    
                    <div class="form-group">
                        <label for="addr">Address:</label>
                        <input type="text" class="form-control" id="addr" style="max-width:500px;">
                    </div>
                    <div class="form-group">
                        <label for="ph">Phone Number:</label>
                        <input type="text" class="form-control" id="ph" style="max-width:300px;">
                    </div>
                   
                     <div class="form-group">
                        <label for="color">Choose color:</label>
                            <select class="form-control" id="color" style="max-width:200px;" onchange="check()">
                                <option>Red</option>
                                <option>Green</option>
                                <option>Purple</option>
                                
                            </select>
                    </div>
                     <div class="form-group">
                        <label for="size">Choose size:</label>
                            <select class="form-control" id="size" style="max-width:200px;" onchange="check()">
                                <option>Small</option>
                                <option>Medium</option>
                                <option>Large</option>
                                
                            </select>
                    </div>
                    <div class="form-group">
                        <label for="price">Price:</label>
                        <input type="text" class="form-control" id="price" style="max-width:300px;" value="10000" disabled>
                    </div>
                    <div class="form-group">
                        <label for="pMethod">Payment Method:</label>
                            <select class="form-control" id="pMethod" style="max-width:200px;" onchange="hs()">
                                <option>MPU Ecommerce</option>
                                <option>Gamma-Net A/C</option>                    
                            </select>
                    </div>

                    <div id="hs" style="display:none">
                    <div class="form-group">
                        <label for="name">Gamma-Net User Name:</label>
                        <input type="text" class="form-control" id="name" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="pwd">Password:</label>
                        <input type="password" class="form-control" id="pwd" style="max-width:300px;">
                    </div>
                    </div>



                    <div class="checkbox">
                        <label><input type="checkbox"> All above data are sure.</label>
                    </div>
                    <button type="submit" class="btn btn-default">Buy</button>
                </form>
            </div>

        </div>
        <!-- /.row -->

        <!-- Related Projects Row -->
        <div class="row">

            <div class="col-lg-12">
                <h3 class="page-header">Related Projects</h3>
            </div>

            <div class="col-sm-3 col-xs-6">
                <a href="#">
                    <img class="img-responsive img-hover img-related" src="http://placehold.it/500x300" alt="">
                </a>
            </div>

            <div class="col-sm-3 col-xs-6">
                <a href="#">
                    <img class="img-responsive img-hover img-related" src="http://placehold.it/500x300" alt="">
                </a>
            </div>

            <div class="col-sm-3 col-xs-6">
                <a href="#">
                    <img class="img-responsive img-hover img-related" src="http://placehold.it/500x300" alt="">
                </a>
            </div>

            <div class="col-sm-3 col-xs-6">
                <a href="#">
                    <img class="img-responsive img-hover img-related" src="http://placehold.it/500x300" alt="">
                </a>
            </div>

        </div>
        <!-- /.row -->

        <hr>

        <!-- Footer -->
      <?php $__env->stopSection(); ?>
        <!-- Footer -->
<?php $__env->startSection('footer'); ?>
    
@parent

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <script language="JavaScript">
        function check()
        {
            a=document.getElementById("color").value;
            b=document.getElementById("size").value;
            if(a=="Red")
            switch (b)
            {
                case "Small": document.getElementById("price").value="10000"; break;
                case "Medium": document.getElementById("price").value="20000"; break;
                case "Large": document.getElementById("price").value="30000"; break;
                default: document.getElementById("price").value="10000";
            }
            else if(a=="Green")
            switch (b)
            {
                case "Small": document.getElementById("price").value="12000"; break;
                case "Medium": document.getElementById("price").value="22000"; break;
                case "Large": document.getElementById("price").value="32000"; break;
                  default: document.getElementById("price").value="10000";
            }
            else
            switch (b)
            {
                case "Small": document.getElementById("price").value="14000"; break;
                case "Medium": document.getElementById("price").value="24000"; break;
                case "Large": document.getElementById("price").value="34000"; break;
                  default: document.getElementById("price").value="10000";
            }
        }
        function hs()
        {
            var pm=document.getElementById("pMethod").value;
            if(pm=="Gamma-Net A/C")
            {
                document.getElementById("hs").style.display="block";
            }
            else
            {
                document.getElementById("hs").style.display="none";
                document.getElementById("name").value="";
                document.getElementById("pwd").value="";
            }
        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mm-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>