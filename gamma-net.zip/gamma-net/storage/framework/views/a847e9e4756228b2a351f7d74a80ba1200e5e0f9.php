<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
    @parent

    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Mobile Prepaid Topup Bill
                    <small>Buy Now</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index">Home</a>
                    </li>
                    <li class="active">Buy your phone bill!</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Content Row -->
         <div class="col-md-9">
                <h2>Mobile Prepaid Topup Buying Successful</h2>
                <p>You bought : <b>Telenor - 10000-MMK</b></p>
                <p>Your Topup Code is : <b>1234 5678 9123 1234</b></p>
                
                
                <p>Thank's alot for using our services</p>
            </div>
        <!-- /.row -->

        <hr>

        <!-- Footer -->
        <?php $__env->stopSection(); ?>
        <!-- Footer -->
<?php $__env->startSection('footer'); ?>
    
@parent

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>