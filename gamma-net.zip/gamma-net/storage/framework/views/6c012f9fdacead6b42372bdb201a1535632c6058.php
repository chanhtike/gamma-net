<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
       
 			
 			<div class="col-md-9">
                <h2>All user annoucement:</h2>
                <p>Annouce to all users from admin:</p>
                <form role="form" action="#">
                	<div class="form-group">
                        <label for="date">Date :</label>
                        <input type="text" class="form-control" id="date" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="title">Title:</label>
                        <input type="text" class="form-control" id="title" style="max-width:300px;">
                    </div>                                      
                    <div class="form-group">
                        <label for="msg">Message:</label>
                        <input type="text" class="form-control" id="msg" style="max-width:300px;">
                    </div>                    
                        <button type="submit" class="btn btn-default">Send</button>
                    <hr>

                    
                    
                </form>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>