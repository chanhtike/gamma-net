<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
 			
 			<div class="col-md-9">
                <h2>ေငြသားလက္က်န္</h2>
                <h3>လူႀကီးမင္း၏ေငြလက္က်န္မွာ : <b> xxxxxx</b> က်ပ္</h3>
                <h4> ကၽြႏ္ုပ္တို႔၏ဝန္ေဆာင္မႈကို အသံုးျပဳသည့္အတြက္အထူးေက်းဇူးတင္ရွိပါသည္။</h4>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.mm-member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>