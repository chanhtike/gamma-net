<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
    @parent
            
            <div class="col-md-9">
                <h2>Mobile Prepaid Topup Buying Successful</h2>
                <p>You bought : <b>Telenor - 10000-MMK</b></p>
                <p>Your Topup Code is : <b>1234 5678 9123 1234</b></p>
                
                <p>Now your Gamma-Net account balance is : <b> xxxx</b> Ks </p>
                <p>Thank's alot for using our services</p>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>