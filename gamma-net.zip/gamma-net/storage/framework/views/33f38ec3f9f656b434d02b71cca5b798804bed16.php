<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
        <script language="JavaScript">
        function hs()
        {
            var a=document.getElementById("type").value;
            if(a=="Bank Transfer")
            {
                document.getElementById("hs").style.display="block";
            }
            else
            {
                document.getElementById("file").value="";
                document.getElementById("hs").style.display="none";
                
            }
        }
        </script>
 			
 			<div class="col-md-9">
                <h2>ေငြသြင္းရန္</h2>
                <p>သင္၏ Gamma-Net Account ထဲသို႔ ေငြေပးသြင္းႏိုင္ပါၿပီ။</p>
                <form role="form" action="mm-cash-in-success">
                	<div class="form-group">
                        <label for="usr">ေငြပမာဏ :</label>
                        <input type="text" class="form-control" id="usr" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="usr">ေပးသြင္းသူအမည္ :</label>
                        <input type="text" class="form-control" id="usr" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="type">ေပးသြင္းမည့္နည္းလမ္း:</label>
                            <select class="form-control" id="type" style="max-width:200px;" onchange="hs()">
                                <option>MPU E-Commerce</option>
                                <option>Bank Transfer</option>
                            </select>
                    </div>
                    <hr>

                    <div id="hs" style="display: none">
                    <p> Bank မွ ေငြလႊဲပို႕ထားေသာ ေျပစာဓါတ္ပံုကို ထည့္သြင္းေပးပါ</p>
                        <div class="form-group">
                            <label for="file">ေျပစာပံုတင္မည္:</label>
                            <input type="file" id="file" style="max-width:300px;">
                        </div>
                    </div>

                     <button type="submit" class="btn btn-default">ေသခ်ာပါသည္</button>
                </form>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.mm-member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>