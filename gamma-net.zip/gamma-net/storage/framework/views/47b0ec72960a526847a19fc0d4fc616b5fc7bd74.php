<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
 			
 			<div class="col-md-9">
                <h2>ေငြသားေပးသြင္းျခင္း လုပ္ငန္းစဥ္ ေအာင္ျမင္ပါသည္</h2>
                <p><b>xxx</b> မိနစ္အတြင္း သင္၏ေငြလက္က်န္မွာ <b>xxx</b> က်ပ္ျဖစ္လာပါလိမ့္မည္။</p>
                <p>ကၽြႏ္ုပ္တို႔၏ဝန္ေဆာင္မႈကို အသံုးျပဳသည့္အတြက္အထူးေက်းဇူးတင္ရွိပါသည္။</p>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.mm-member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>