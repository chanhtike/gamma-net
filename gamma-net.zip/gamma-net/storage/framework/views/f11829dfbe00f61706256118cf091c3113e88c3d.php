<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
 			
 			<div class="col-md-9">
                <h2>ကၽြႏု္ပ္၏ကိုယ္ပိုင္စာမ်က္ႏွာ</h2>
                
                <p>ဤစာမ်က္ႏွာသည္ သင္၏ကုိယ္ပိုင္စာမ်က္ႏွာျဖစ္ပါသည္။</p>
                  <img src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=GN1234&nbsp;:&nbsp;Chan&nbsp;Htike" title="Link to Google.com" />
                <p>ID :<b> GN1234</b></p>
                <p>အမည္ : <b>Chan Htike</b></p>
                <p>ေနရပ္လိပ္စာ : <b>No.4, Zay Chaung St, Pathein</b></p>
                <p>ဖုန္းနံပါတ္ : <b>09-794517433</b></p>
                <p>Email လိပ္စာ : <b><u>gn-user@gamma-net.com</u></b></p>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.mm-member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>