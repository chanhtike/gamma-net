<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
 			<script language="JavaScript">
                
                a=1;
                function asd()
                    {
                        if(a==1)
                        {
                            document.getElementById("hideshow").style.display="block";
                            document.getElementById("pwandcancel").value="Cancel";
                            a=2;

                        }
                        else
                        {
                            document.getElementById("hideshow").style.display="none";
                            document.getElementById("pwandcancel").value="Change Password";
                            a=1;
                            document.getElementById("np1").value="";
                            document.getElementById("np2").value="";
                        }
                    }
            </script>
 			<div class="col-md-9">
 			   <h2> Account Settings </h2>
                <form role="form" action="member-home">
                    <div class="form-group">
                        <label for="usr">User Name:</label>
                        <input type="text" class="form-control" id="usr" style="max-width:300px;" value="Chan Htike">
                    </div>
                    <div class="form-group">
                        <label for="email">Email address:</label>
                        <input type="email" class="form-control" id="email" style="max-width:300px;" value="chanhtike@gamma-net.com" readonly> That's cannot be changed*
                    </div>

                    <hr>
                <div class="form-group">
                    <input type="button" id="pwandcancel" class="btn btn-default" onclick="asd()" value="Change Password">
                </div>

                <div id="hideshow" style="display:none">
                     <div class="form-group">
                        <label for="op">Old Password:</label>
                        <input type="password" class="form-control" id="op" style="max-width:300px;" value="123456" disabled>
                    </div>
                     <div class="form-group">
                        <label for="np1">New Password:</label>
                        <input type="password" class="form-control" id="np1" style="max-width:300px;">
                    </div>
                     <div class="form-group">
                        <label for="np2">Confirm New Password:</label>
                        <input type="password" class="form-control" id="np2" style="max-width:300px;">
                    </div>
                   
                </div>

                    <hr>

                    <div class="form-group">
                        <label for="addr">Address:</label>
                        <input type="text" class="form-control" id="addr" style="max-width:500px;" value="No-4, Nyaung Pin Tha St.">
                    </div>
                    <div class="form-group">
                        <label for="ph">Phone Number:</label>
                        <input type="text" class="form-control" id="ph" style="max-width:300px;" value="09-794517433">
                    </div>
                   
                     <div class="form-group">
                        <label for="sel1">Gender:</label>
                            <select class="form-control" id="sel1" style="max-width:200px;">
                                <option selected>Male</option>
                                <option>Female</option>
                                <option>Confuse</option>                                
                            </select>
                  	</div>
                  	<button type="submit" class="btn btn-default">Update</button>
                </form>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>