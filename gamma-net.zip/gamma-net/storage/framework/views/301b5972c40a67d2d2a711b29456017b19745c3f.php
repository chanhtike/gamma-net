<?php $__env->startSection('title', 'Page Title'); ?>
<?php $__env->startSection('sidebar'); ?>
	@parent
		<p>This is appended to the master sidebar.</p>
	<?php $__env->stopSection(); ?>
<?php $__env->startSection('fuck'); ?>
<h1> fuck you!!</h1>
 <p>
This paragraph
contains a lot of lines
in the source code,
but the browser
ignores it.
</p>

<p>
This paragraph
contains         a lot of spaces
in the source         code,
but the        browser
ignores it.
</p>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
		<h2><?php echo e($name); ?></h2>
		<p>This is my body content.</p>
	<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>