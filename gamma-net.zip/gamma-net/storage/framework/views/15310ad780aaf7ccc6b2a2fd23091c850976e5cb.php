<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
 			
 			<div class="col-md-9">
                <h2>ကၽြႏု္ပ္၏ level ႏွင့္ downline</h2>
                <p>ကၽြႏု္ပ္၏  Level : <b>Platinum</b></p>
                <p>ကၽြႏု္ပ္၏  Bonus : <b>xxxxxx</b> Ks per Month</p>
                <div style="width:95%; height:100%; overflow:auto; padding:5px;">
                 <div class="tree" style="width: 600px; height:300px;">
					<ul>
						<li>
							<a href="#">Diamiond</a>
								<ul>
									<li>
										<a href="#">Platinum</a>
											<ul>
												<li>
													<a href="#">Gold</a>
														<ul>
															<li>
																<a href="#">Silver</a>
															</li>
															<li>
																<a href="#">Silver</a>
															</li>
														</ul>
												</li>
												<li>
													<a href="#">Gold</a>
														<ul>
															<li>
																<a href="#">Silver</a>
															</li>
															<li>
																<a href="#">Silver</a>
															</li>
														</ul>
												</li>
											</ul>
									</li>
									<li>
										<a href="#">Platinum</a>
											<ul>
												<li>
													<a href="#">Gold</a>
														<ul>
															<li>
																<a href="#">Silver</a>
															</li>
															<li>
																<a href="#">Silver</a>
															</li>
														</ul>
												</li>
												<li>
													<a href="#">Gold</a>
														<ul>
															<li>
																<a href="#">Silver</a>
															</li>
															<li>
																<a href="#">Silver</a>
															</li>
														</ul>
												</li>
											</ul>
									</li>
								</ul>					
						</li>
					</ul>
				</div>
				</div>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.mm-member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>