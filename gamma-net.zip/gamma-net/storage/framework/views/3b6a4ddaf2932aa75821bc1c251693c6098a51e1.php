<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
    <script language="JavaScript">
    function remitoption()
    {
        var a=document.getElementById("tmethod").value;
        if(a=="Transfer to Bank A/C")
        {
            document.getElementById("toBank").style.display="block";
            document.getElementById("toGn").style.display="none";
            document.getElementById("gn-ac").value="";
            document.getElementById("gn-rname").value="";
            document.getElementById("gn-rnrc").value="";
            document.getElementById("gn-amt").value="";
            document.getElementById("gn-charges").value="";
            document.getElementById("gn-total").value="";
        }
        else
        {
             document.getElementById("toGn").style.display="block";
            document.getElementById("toBank").style.display="none";
            document.getElementById("rnum").value="";
            document.getElementById("rname").value="";
            document.getElementById("bname").value="";
            document.getElementById("rnrc").value="";
             document.getElementById("amt").value="";
            document.getElementById("charges").value="";
            document.getElementById("total").value="";
        }
    }
    function cBank()
    {

        var ramt=parseInt(document.getElementById("amt").value, 10);
        if(ramt<=1000)
        {
             document.getElementById("a-alert").style.display="block";
            document.getElementById("a-alert").innerHTML= "*Value must be more than 1000 Ks";
            document.getElementById("amt").value="";
            document.getElementById("charges").value="";
            document.getElementById("total").value="";
        }
        else if(ramt>1000 && ramt<=50000)
        {
            document.getElementById("charges").value=500;
            document.getElementById("total").value=ramt+500;
            document.getElementById("a-alert").style.display="none";
        }
        else if(ramt>50000 && ramt<1000000)
        {
            var chgs=ramt*1/100;
            document.getElementById("charges").value=chgs;
            document.getElementById("total").value=ramt+chgs;
            document.getElementById("a-alert").style.display="none";
        }
        else if(ramt>1000000)
        {
            document.getElementById("a-alert").style.display="block";
            document.getElementById("a-alert").innerHTML="*You can't remit more than 1 million per day.";
            document.getElementById("amt").value="";
            document.getElementById("charges").value="";
            document.getElementById("total").value="";
        }
        else
        {
            document.getElementById("a-alert").style.display="block";
            document.getElementById("a-alert").innerHTML="*Invalid value please try again.";
            document.getElementById("amt").value="";
            document.getElementById("charges").value="";
            document.getElementById("total").value="";
        }
    }
    function GNBank()
    {

        var gn_ramt=parseInt(document.getElementById("gn-amt").value, 10);
        if(gn_ramt<=1000)
        {
            document.getElementById("gn-a-alert").style.display="block";
            document.getElementById("gn-a-alert").innerHTML="*Value must be more than 1000 Ks";
            document.getElementById("gn-amt").value="";
            document.getElementById("gn-charges").value="";
            document.getElementById("gn-total").value="";
        }
        else if(gn_ramt>1000 && gn_ramt<=50000)
        {
            document.getElementById("gn-charges").value=500;
            document.getElementById("gn-total").value=gn_ramt+500;
            document.getElementById("gn-a-alert").style.display="none";
        }
        else if(gn_ramt>50000 && gn_ramt<=1000000)
        {
            var gn_chgs=gn_ramt*1/100;
            document.getElementById("gn-charges").value=gn_chgs;
            document.getElementById("gn-total").value=gn_ramt+gn_chgs;
            document.getElementById("gn-a-alert").style.display="none";
        }
        else if(gn_ramt>1000000)
        {
            document.getElementById("gn-a-alert").style.display="block";
            document.getElementById("gn-a-alert").innerHTML="*You can't remit more than 1 million per day.";
            document.getElementById("gn-amt").value="";
            document.getElementById("gn-charges").value="";
            document.getElementById("gn-total").value="";
        }
        else
        {
            document.getElementById("gn-a-alert").style.display="block";
            document.getElementById("gn-a-alert").innerHTML="*Invalid value please try again.";
            document.getElementById("gn-amt").value="";
            document.getElementById("gn-charges").value="";
            document.getElementById("gn-total").value="";
        }
    }
    </script>
 			
 			<div class="col-md-9">
                <h2>Money Transfer</h2>
                <p>You can transfer cash from your Gamma-Net Account to Other</p>
                <form role="form" action="remit-confirm">
                	<div class="form-group">
                        <label for="email">Your Email :</label>
                        <input type="text" class="form-control" id="email" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="pass">Your Password :</label>
                        <input type="password" class="form-control" id="pass" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="nrc">Your NRC No :</label>
                        <input type="text" class="form-control" id="nrc" style="max-width:300px;">
                    </div>
                    
                    <div class="form-group">
                        <label for="tmethod">Transfer Method :</label>
                            <select class="form-control" id="tmethod" style="max-width:200px;" onchange="remitoption()">
                                <option>Transfer to Bank A/C</option>
                                <option>Transfer to Gamma-Net A/C</option>
                                <option disabled>Transfer to Agent</option>
                            </select>
                    </div>
                <hr>

                <div id="toBank" style="display:block">
                    <div class="form-group">
                        <label for="rnum">Receiver A/C Number :</label>
                        <input type="text" class="form-control" id="rnum" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="rname">Receiver A/C Name :</label>
                        <input type="text" class="form-control" id="rname" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="bname">Bank Name :</label>
                        <input type="text" class="form-control" id="bname" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="rnrc">Receiver NRC No :</label>
                        <input type="text" class="form-control" id="rnrc" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="amt">Remit Amount :</label>
                        <input type="text" class="form-control" id="amt" style="max-width:300px;" onchange="cBank()">
                        <p id="a-alert" style="display:none; color:red"></p>
                    </div>
                    <div class="form-group">
                        <label for="charges">Service Charges :</label>
                        <input type="text" class="form-control" id="charges" style="max-width:300px;" disabled>
                    </div>
                    <div class="form-group">
                        <label for="total">Total Charges :</label>
                        <input type="text" class="form-control" id="total" style="max-width:300px;" disabled>
                    </div>
                </div>

                    
                <div id="toGn" style="display:none">
                    
                    <div class="form-group">
                        <label for="gn-ac">Receiver's Gamma Net A/C No :</label>
                        <input type="text" class="form-control" id="gn-ac" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="gn-rname">Receiver Name :</label>
                        <input type="text" class="form-control" id="gn-rname" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="gn-rnrc">Receiver NRC No :</label>
                        <input type="text" class="form-control" id="gn-rnrc" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="gn-amt">Remit Amount :</label>
                        <input type="text" class="form-control" id="gn-amt" style="max-width:300px;" onchange="GNBank()">
                        <p id="gn-a-alert" style="display:none; color:red"></p>
                    </div>
                    <div class="form-group">
                        <label for="gn-charges">Service Charges :</label>
                        <input type="text" class="form-control" id="gn-charges" style="max-width:300px;" disabled>
                    </div>
                    <div class="form-group">
                        <label for="gn-total">Total Charges :</label>
                        <input type="txt" class="form-control" id="gn-total" style="max-width:300px;" disabled>
                    </div>
                </div>
                <hr>



                    <div class="checkbox">
                        <label><input type="checkbox"> I am sure to Transfer cash from my Gamma-Net A/C.</label>
                    </div>
                     <button type="submit" class="btn btn-default">Next</button>
                </form>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>