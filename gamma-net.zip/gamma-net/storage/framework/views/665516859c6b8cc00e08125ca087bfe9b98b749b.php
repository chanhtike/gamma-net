<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
 			
 			<div class="col-md-9">
                <h2>Cash In Process Successful</h2>
                <p>Your balance will be <b>xxx</b> Ks within <b>xxx</b> minutes.</p>
                <p>Thank's for using our services</p>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>