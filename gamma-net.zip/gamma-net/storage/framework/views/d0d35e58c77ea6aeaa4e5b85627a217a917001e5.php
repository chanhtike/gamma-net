<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
        <script language="JavaScript">
            function hs()
            {
                var a=document.getElementById("type").value;
                if(a=="Bank Transfer")
                {
                    document.getElementById("hs").style.display="block";
                }
                else
                {
                    document.getElementById("file").value="";
                    document.getElementById("hs").style.display="none";
                    
                }
            }
        </script>
 			
 			<div class="col-md-9">
                <h2>Cash In</h2>
                <p>You can now add cash to your Gamma-Net Account</p>
                <form role="form" action="cash-in-success">
                	<div class="form-group">
                        <label for="usr">Amount :</label>
                        <input type="text" class="form-control" id="usr" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="usr">Depositor Name:</label>
                        <input type="text" class="form-control" id="usr" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="type">Payment Method:</label>
                            <select class="form-control" id="type" style="max-width:200px;" onchange="hs()">
                                <option>MPU E-Commerce</option>
                                <option>Bank Transfer</option>
                            </select>
                    </div>
                    <hr>

                    <div id="hs" style="display: none">
                    <p> Please insert photo of bank remit receipt</p>
                        <div class="form-group">
                            <label for="file">Upload photo:</label>
                            <input type="file" id="file" style="max-width:300px; height:50px">
                        </div>
                    </div>
                     <button type="submit" class="btn btn-default">OK</button>
                </form>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>