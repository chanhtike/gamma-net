<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
         			
 			<div class="col-md-9">
                <h2>Insert Item</h2>
                <p>Insert New item to sale</p>
                <form role="form" action="cash-in-success">
                	<div class="form-group">
                        <label for="p-name">Product Name :</label>
                        <input type="text" class="form-control" id="p-name" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="category">Category:</label>
                        <input type="text" class="form-control" id="category" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="color">Color:</label>
                        <input type="text" class="form-control" id="color" style="max-width:300px;">   
                    </div>
                    <div class="form-group">
                        <label for="size">Size:</label>
                        <input type="text" class="form-control" id="size" style="max-width:300px;">   
                    </div>
                    <div class="form-group">
                        <label for="price">Price:</label>
                        <input type="text" class="form-control" id="price" style="max-width:300px;">   
                    </div>
                    <div class="form-group">
                        <label for="amount">Amount:</label>
                        <input type="text" class="form-control" id="amount" style="max-width:300px;">   
                    </div>                      
                    <div class="form-group">
                        <label for="photo">Upload Product Photo:</label>
                        <input type="file" id="photo" style="max-width:300px; height:50px">
                    </div>
                   <div class="form-group">
                        <label for="amount">Description:</label>
                        <input type="text" class="form-control" id="amount" style="max-width:300px;">   
                    </div>   
                     <button type="submit" class="btn btn-default">Add</button>
                </form>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.cashier-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>