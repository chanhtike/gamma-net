<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
 			
 			<div class="col-md-9">
                <h2>Cash Balance</h2>
                <h3>Your ramaining balance is : <b> xxxxxx</b> Ks</h3>
                <h4> Thank's for using our services</h4>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>