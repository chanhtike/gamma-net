<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
    @parent

    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Mobile Prepaid Topup Bill
                    <small>Buy Now</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index">Home</a>
                    </li>
                    <li class="active">Buy your phone bill!</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Content Row -->
        <div class="row">
            <div class="col-lg-12">
                <p>You can buy Mobile Prepaid Topup Bill from Gamma-Net A/C or MPU E-Commerce</p>
                 <form role="form" action="topup-confirm">
                    <div class="form-group">
                        <label for="usr">Your Name:</label>
                        <input type="text" class="form-control" id="usr" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="email">Email address:</label>
                        <input type="email" class="form-control" id="email" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="ph">Phone Number:</label>
                        <input type="text" class="form-control" id="ph" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="ptype">Topup Method:</label>
                            <select class="form-control" id="ptype" style="max-width:200px;" onchange="gn()">
                                <option>From MPU Ecommerce</option>
                                <option>From Gamma-Net A/C</option>
                            </select>
                    </div>
                     <div class="form-group" id="gp" style="display:none;">
                        <label for="pass">Enter Gamma Net Password:</label>
                        <input type="password" class="form-control" id="pass" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="sel1">Choose Telecom :</label>
                            <select class="form-control" id="sel1" style="max-width:200px;">
                                <option>Telenor</option>
                                <option>MPT</option>
                                <option>Ooredoo</option>
                                 <option>MecTel</option>
                            </select>
                    </div>
                    <div class="form-group">
                        <label for="sel1">Choose Amount :</label>
                            <select class="form-control" id="sel1" style="max-width:200px;">
                                <option>1000-MMK</option>
                                <option>3000-MMK</option>
                                <option>5000-MMK</option>
                                <option>10000-MMK</option>
                            </select>
                    </div>
                    
                    <div class="checkbox">
                        <label><input type="checkbox"> I am sure to buy top up card from my Gamma-Net Cash.</label>
                    </div>
                     <button type="submit" class="btn btn-default">Next</button>
                </form>
            </div>
        </div>
        <!-- /.row -->

        <hr>

        <!-- Footer -->
        <?php $__env->stopSection(); ?>
        <!-- Footer -->
<?php $__env->startSection('footer'); ?>
    
@parent

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <script>
        function gn()
        {
            var a=document.getElementById("ptype").value;
            if(a=="From Gamma-Net A/C")
            {
                document.getElementById("gp").style.display="block";
            }
            else
            {
                document.getElementById("gp").style.display="none";
                document.getElementById("pass").value="";
            }
        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>