<?php $__env->startSection('title', 'Gamma-Net'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebar'); ?>
 	@parent
 			
 			<div class="col-md-9">
                <h2>Please check these remit data exactly</h2>
                <p>Sender Name  -<b>xxxx</b></p>
                <p>Receiver Name -<b>xxxx</b></p>
                <p>Remit Amount -<b>xxxx</b></p>
                <div class="checkbox">
                        <label><input type="checkbox">All data above are right</label>
                    </div>
                    <a href="remit-success" class="btn btn-primary">Remit</a>
            </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
@parent
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>