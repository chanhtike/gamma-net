@extends('layouts.member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
 			
 			<div class="col-md-9">
                <h2>Please enter your password to view your cash balance</h2>
                <form role="form" action="cash-balance">
                    <div class="form-group">
                        <label for="confirm">Please enter your password:</label>
                        <input type="password" class="form-control" id="confirm" style="max-width:300px;">
                    </div>
                    
                    <button type="submit" class="btn btn-default">Go!</button>
                </form>
            </div>

    @endsection

@section('footer')
@parent
@endsection


