@extends('layouts.member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
 			
 			<div class="col-md-9">
                <h2>Please check these remit data exactly</h2>
                <p>Sender Name  -<b>xxxx</b></p>
                <p>Receiver Name -<b>xxxx</b></p>
                <p>Remit Amount -<b>xxxx</b></p>
                <div class="checkbox">
                        <label><input type="checkbox">All data above are right</label>
                    </div>
                    <a href="remit-success" class="btn btn-primary">Remit</a>
            </div>

    @endsection

@section('footer')
@parent
@endsection
