@extends('layouts.member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
    @parent
                <script language="JavaScript">
                function show()
                {
                    
                    var a="1";
                    if(a=="1")
                    {
                        document.getElementById("prepaid").style.display="block";
                    }
                    else
                    {
                        document.getElementById("product").style.display="block";
                    }
                }
                
                </script>

            <div class="col-md-9">
                <h2>Monthly Mark</h2>
                <p>You can make monthly mark here, monthly mark for this month is :</p>
               <form role="form" action="#">
                 <input type="button" onclick="show()" value="Show Mark"/>   
                 <br>
                <div id="prepaid" style="display:none">
                   <p>Buy Phone Bill <br>
                   Cost : <b>10,000</b></p>
                </div>

                    
                <div id="product" style="display:none">
                    <p>Buy Product
                     <br>
                   Cost : <b>10,000</b></p>
                </div>
                <hr>


                 
                     <button type="submit" class="btn btn-default">Mark Now</button>
                </form>
            </div>
               
    @endsection

@section('footer')
@parent
@endsection


