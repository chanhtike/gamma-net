@extends('layouts.cashier-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
         			
 			<div class="col-md-9">
                <h2>View Cash In Hand</h2>
                <p>View Cash In Hand of sold products!</p>
                <form role="form" action="cash-in-success">
                	<div class="form-group">
                        <label for="cash-inhand">Cash In Hand :</label>
                        <input type="text" class="form-control" id="cash-inhand" style="max-width:300px;">MMK
                    </div>                        
                    <div class="form-group">
                        <label for="withdrawl-amt">Withdrawl Amount :</label>
                        <input type="text" class="form-control" id="withdrawl-amt" style="max-width:300px;">MMK
                    </div>
                  
                     <button type="button" class="btn btn-default">Confirm</button>
                </form>
            </div>

    @endsection

@section('footer')
@parent
@endsection


