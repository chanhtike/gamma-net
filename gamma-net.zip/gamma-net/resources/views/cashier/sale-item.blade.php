@extends('layouts.cashier-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
         			
 			<div class="col-md-9" >
                <h2>Sale Item</h2>
                <h3>Please confirm the following requests</h3>
                <div style="width:95%; height:100%; overflow:auto; padding:5px;">
                <div class="transitions" style="width: 800px; height:300px;">
                    <table>
                    <tr>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Color</th>
                        <th>Size</th>
                        <th>Amount</th>
                        <th>Price</th>                        
                        <th>
                         Confirm
                        </th>
                        <th>
                          Cancel
                        </th>                
                    </tr> 
                    <tr>
                        <td>Long Pant 123</td>
                        <td>Men Pant</td>
                        <td>Grey</td>
                        <td>L</td>
                        <td>2</td>
                        <td>20,000</td>
                        <td>
                          <button type="button">Confirm</button>
                        </td>
                        <td>
                          <button type="button">Cancel</button>
                        </td>  
                    </tr>       
                    </table>         
                </div>
                </div>
               
            </div>

    @endsection

@section('footer')
@parent
@endsection


