@extends('layouts.member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
    
         
 			<div class="col-md-9" >
                <h2>User Annoucement</h2>
                <h3>Please follow under our annoucement</h3>
                
               
                                 
                
                <div style="width:95%; height:100%; overflow:auto; padding:5px;">
                <div class="transitions" style="width: 800px; height:300px;">
                    <table>
                    <tr>
                        <th>Date</th>
                        <th>Message</th>
                     </tr> 
                    <tr>
                        <td>11/11/2016</td>
                        <td>All Members! Happy New Year !!</td>
                    </tr>
                     <tr>
                        <td>14/2/2017</td>
                        <td>Happy Valentines' Day</td>
                    </tr>              
                    </table>         
                </div>
                </div>
               
            </div>

           


    @endsection

@section('footer')
@parent
@endsection


