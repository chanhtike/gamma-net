@extends('layouts.admin-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
       
 			
 			<div class="col-md-9">
                <h2>Cash Deposit</h2>
                <p>You can now deposit cash to user A/C:</p>
                <form role="form" action="#">
                	<div class="form-group">
                        <label for="user-id">User ID :</label>
                        <input type="text" class="form-control" id="user-id" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="user-name">User Name:</label>
                        <input type="text" class="form-control" id="user-name" style="max-width:300px;">
                    </div>
                    <button type="button" class="btn btn-default">Search</button>
                    <hr>
                    
                    <div class="form-group">
                        <label for="dep-amt">Deposit Amount:</label>
                        <input type="text" class="form-control" id="dep-amt" style="max-width:300px;">
                    </div>
                        <button type="submit" class="btn btn-default">Insert</button>
                    <hr>

                    
                    
                </form>
            </div>

    @endsection

@section('footer')
@parent
@endsection


