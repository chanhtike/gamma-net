@extends('layouts.admin-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
       
 			
 			<div class="col-md-9">
                <h2>All user annoucement:</h2>
                <p>Annouce to all users from admin:</p>
                <form role="form" action="#">
                	<div class="form-group">
                        <label for="date">Date :</label>
                        <input type="text" class="form-control" id="date" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="title">Title:</label>
                        <input type="text" class="form-control" id="title" style="max-width:300px;">
                    </div>                                      
                    <div class="form-group">
                        <label for="msg">Message:</label>
                        <input type="text" class="form-control" id="msg" style="max-width:300px;">
                    </div>                    
                        <button type="submit" class="btn btn-default">Send</button>
                    <hr>

                    
                    
                </form>
            </div>

    @endsection

@section('footer')
@parent
@endsection


