@extends('layouts.admin-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
       
 			
 			<div class="col-md-9">
                <h2>Change Mark Type:</h2>
                <p>Change Mark Type (1)for Buy Products, (2)for Buy PhoneBill, (3)for Buy --:</p>
                <form role="form" action="#">                	
                    <div class="form-group">
                        <label for="current">Current Mark Type:</label>
                        <input type="text" class="form-control" id="current" style="max-width:300px;">
                    </div>                                      
                    <div class="form-group">
                        <label for="new">New Mark Type :</label>
                            <select class="form-control" id="new" style="max-width:200px;" onchange="remitoption()">
                                <option>1</option>
                                <option>2</option>
                                <option disabled>3</option>
                            </select>
                    </div>                    
                        <button type="submit" class="btn btn-default">Change</button>
                    <hr>

                    
                    
                </form>
            </div>

    @endsection

@section('footer')
@parent
@endsection


