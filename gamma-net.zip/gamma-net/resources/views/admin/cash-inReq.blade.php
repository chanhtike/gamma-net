@extends('layouts.admin-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
    
         
 			<div class="col-md-9" >
                <h2>Cash in Requests</h2>
                <h3>Please confirm the following requests</h3>
                
               
                                 
                
                <div style="width:95%; height:100%; overflow:auto; padding:5px;">
                <div class="transitions" style="width: 800px; height:300px;">
                    <table>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>User-Id</th>
                        <th>User-name</th>
                        <th>Description</th>
                        <th>Amount</th>
                        <th>:Photo</th>
                        <th>
                         Confirm
                        </th>
                        <th>
                          Cancel
                        </th>                
                    </tr> 
                    <tr>
                        <th>9.2.2017</th>
                        <th>9:10 AM</th>
                        <th>GN-0004</th>
                        <th>U Ko Ko</th>
                        <th>From Bank</th>
                        <th>20,000</th>
                        <th>:Photo</th>
                        <th>
                          <button type="button">Confirm</button>
                        </th>
                        <th>
                          <button type="button">Cancel</button>
                        </th>  
                    </tr>
                      <tr>
                        <th>14.2.2017</th>
                        <th>9:10 AM</th>
                        <th>GN-0004</th>
                        <th>U Ko Aye</th>
                        <th>From G-Net</th>
                        <th>20,000</th>
                        <th>:Photo</th>
                        <th>
                          <button type="button">Confirm</button>
                        </th>
                        <th>
                          <button type="button">Cancel</button>
                        </th>  
                    </tr>             
                    </table>         
                </div>
                </div>
               
            </div>

           


    @endsection

@section('footer')
@parent
@endsection


