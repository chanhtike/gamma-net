@extends('layouts.admin-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
       
 			
 			<div class="col-md-9">
                <h2>View User</h2>
                <p>You can now search user data:</p>
                <form role="form" action="#">
                	<div class="form-group">
                        <label for="user-id">User ID :</label>
                        <input type="text" class="form-control" id="user-id" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="user-name">User Name:</label>
                        <input type="text" class="form-control" id="user-name" style="max-width:300px;">
                    </div>
                    <button type="button" class="btn btn-default">Search</button>
                    <hr>
                    <div class="form-group">
                        <label for="gender">Gender:</label>
                        <input type="text" class="form-control" id="gender" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="address">Address:</label>
                        <input type="text" class="form-control" id="address" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="phone-number">Phone Number:</label>
                        <input type="text" class="form-control" id="phone-number" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="text" class="form-control" id="email" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="wallet">Wallet:</label>
                        <input type="text" class="form-control" id="wallet" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="refer-id">Reference ID:</label>
                        <input type="text" class="form-control" id="refer-id" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="level">Level:</label>
                        <input type="text" class="form-control" id="level" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="downline1">Downline 1:</label>
                        <input type="text" class="form-control" id="downline1" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="downline2">Downline 2:</label>
                        <input type="text" class="form-control" id="downline2" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="user-status">User Status:</label>
                        <input type="text" class="form-control" id="user-status" style="max-width:300px;">
                    </div>

                    <hr>

                    
                    
                </form>
            </div>

    @endsection

@section('footer')
@parent
@endsection


