@extends('layouts.admin-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
       
 			
 			<div class="col-md-9">
                <h2>End of Month</h2>
                <p>Run End of Month if you sure to close monthly:</p>
                <form role="form" action="#">
                	
                        <button type="submit" class="btn btn-default">Confirm</button>
                    <hr>

                    
                    
                </form>
            </div>

    @endsection

@section('footer')
@parent
@endsection


