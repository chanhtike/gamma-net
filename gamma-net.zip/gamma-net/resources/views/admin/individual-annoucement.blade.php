@extends('layouts.admin-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
       
 			
 			<div class="col-md-9">
                <h2>Individual user annoucement:</h2>
                <p>Annouce to a user from admin:</p>
                <form role="form" action="#">
                	<div class="form-group">
                        <label for="user-id">User ID :</label>
                        <input type="text" class="form-control" id="user-id" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="user-name">User Name:</label>
                        <input type="text" class="form-control" id="user-name" style="max-width:300px;">
                    </div>                                      
                    <div class="form-group">
                        <label for="msg">Message:</label>
                        <input type="text" class="form-control" id="msg" style="max-width:300px;">
                    </div>                    
                        <button type="submit" class="btn btn-default">Send</button>
                    <hr>

                    
                    
                </form>
            </div>

    @endsection

@section('footer')
@parent
@endsection


