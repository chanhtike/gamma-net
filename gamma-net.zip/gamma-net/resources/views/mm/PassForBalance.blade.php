@extends('layouts.mm-member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
 			
 			<div class="col-md-9">
                <h2>သင့္ပိုင္ဆိုင္ေငြကိုၾကည့္ရန္ password ရိုက္ထည့္ေပးပါ</h2>
                <form role="form" action="mm-cash-balance">
                    <div class="form-group">
                        <label for="confirm">password ရိုက္ထည့္ေပးပါ :</label>
                        <input type="password" class="form-control" id="confirm" style="max-width:300px;">
                    </div>
                    
                    <button type="submit" class="btn btn-default">ၾကည့္မည္</button>
                </form>
            </div>

    @endsection

@section('footer')
@parent
@endsection


