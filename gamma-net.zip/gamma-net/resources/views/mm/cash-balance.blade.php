@extends('layouts.mm-member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
 			
 			<div class="col-md-9">
                <h2>ေငြသားလက္က်န္</h2>
                <h3>လူႀကီးမင္း၏ေငြလက္က်န္မွာ : <b> xxxxxx</b> က်ပ္</h3>
                <h4> ကၽြႏ္ုပ္တို႔၏ဝန္ေဆာင္မႈကို အသံုးျပဳသည့္အတြက္အထူးေက်းဇူးတင္ရွိပါသည္။</h4>
            </div>

    @endsection

@section('footer')
@parent
@endsection


