@extends('layouts.mm-member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
    @parent
            
            <div class="col-md-9">
                <h2>ေငြျဖည့္ကဒ္ဝယ္ယူျခင္းလုပ္ငန္းစဥ္ေအာင္ျမင္ပါသည္</h2>
                <p>သင္ဝယ္ယူထားေသာကတ္ဒ္ : <b>Telenor - 10000-MMK</b></p>
                <p>ေငြျဖည့္ကုတ္ဒ္နံပါတ္ : <b>1234 5678 9123 1234</b></p>
                
                <p>သင္၏ Gamma-Net လက္က်န္ေငြမွာ  : <b> xxxx</b> Ks </p>
                <p>ကြ်ႏု္ပ္တို႔ဝန္ေဆာင္မႈမ်ားကိုအသံုးျပဳျခင္းအတြက္အထူးေက်းဇူးတင္ရွိပါသည္။</p>
            </div>

    @endsection

@section('footer')
@parent
@endsection


