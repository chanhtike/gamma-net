@extends('layouts.mm-member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
 			
 			<div class="col-md-9" >
                <h2>ေငြသားအထုတ္အသြင္းစာရင္း</h2>
                <h4>Chan Htike</h4>
                <h6>User ID: <b> GN1234</b></h6>
                 <form role="form" action="#">                    
                    <div class="form-group">
                        <label for="s-date">စတင္သည့္ရက္စြဲ :</label>
                        <input type="text" class="form-control" id="s-date" style="max-width:300px;" onfocus="showCalender1()" >
                    </div>
                    <div id="datepicker1" style="display:none;" onchange="hideCalender1()"></div>

                    <div class="form-group">
                        <label for="e-date">အဆံုးသတ္ရက္စြဲ :</label>
                        <input type="text" class="form-control" id="e-date" style="max-width:300px;" onfocus="showCalender()" >
                    </div>
                     <div id="datepicker" style="display:none;" onchange="hideCalender()"></div>
                    <button type="submit" class="btn btn-default">ရွာမယ္</button>
                </form>
<hr>
                <div style="width:95%; height:100%; overflow:auto; padding:5px;">
                <div class="transitions" style="width: 800px; height:300px;">
                    <table>
                    <tr>
                        <th>ရက္စြဲ</th>
                        <th>ျပဳလုပ္မႈ</th>
                        <th>အေၾကာင္းအရာ</th>
                        <th>ေငြထုတ္</th>
                        <th>ေငြသြင္း</th>
                        <th>ေငြလက္က်န္ </th>
                    </tr> 
                    <tr>
                        <td>11/11/2016</td>
                        <td>Remit</td>
                        <td>Cost of Goods</td>
                        <td>202000</td>
                        <td>-</td>
                        <td>500000</td>
                    </tr>
                     <tr>
                        <td>11/11/2016</td>
                        <td>Deposit</td>
                        <td>Bonus</td>
                        <td>-</td>
                        <td>502000</td>
                        <td>1002000</td>
                    </tr> 
                    <tr>
                        <td>21/11/2016</td>
                        <td>Remit</td>
                        <td>Cash</td>
                        <td>2000</td>
                        <td>-</td>
                        <td>1000000</td>
                    </tr>                        
                    </table>         
                </div>
                </div>
               
            </div>
            <script src="external/jquery/jquery.js"></script>
<script src="jquery-ui.js"></script>
<script>
function showCalender()
{
    document.getElementById("e-date").value=document.getElementById("datepicker").value;
    document.getElementById("datepicker").style.display="block";
}
function hideCalender()
{
    document.getElementById("datepicker").style.display="none";
    document.getElementById("e-date").value=document.getElementById("datepicker").value;
}
function showCalender1()
{
    document.getElementById("s-date").value=document.getElementById("datepicker1").value;
    document.getElementById("datepicker1").style.display="block";
}
function hideCalender1()
{
    document.getElementById("datepicker1").style.display="none";
    document.getElementById("s-date").value=document.getElementById("datepicker1").value;
}





$( "#datepicker" ).datepicker({
    inline: true
});
$( "#datepicker1" ).datepicker({
    inline: true
});




</script>


    @endsection

@section('footer')
@parent
@endsection


