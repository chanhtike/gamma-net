@extends('layouts.mm-member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
 			
 			<script language="JavaScript">
                
                a=1;
                function asd()
                    {
                        if(a==1)
                        {
                            document.getElementById("hideshow").style.display="block";
                            document.getElementById("pwandcancel").value="Cancel";
                            a=2;

                        }
                        else
                        {
                            document.getElementById("hideshow").style.display="none";
                            document.getElementById("pwandcancel").value="Change Password";
                            a=1;
                             document.getElementById("np1").value="";
                            document.getElementById("np2").value="";
                        }
                    }
            </script>
            <div class="col-md-9">
 			   <h2> အေကာင့္ကိုျပင္ဆင္မည္ </h2>
                <form role="form" action="mm-member-home">
                    <div class="form-group">
                        <label for="usr"အမည္ :</label>
                        <input type="text" class="form-control" id="usr" style="max-width:300px;" value="Chan Htike">
                    </div>
                    <div class="form-group">
                        <label for="email">E-Mail လိပ္စာ :</label>
                        <input type="email" class="form-control" id="email" style="max-width:300px;" value="chanhtike@gamma-net.com" readonly> That's cannot be changed*
                    </div>
                     <hr>
                <div class="form-group">
                    <input type="button" id="pwandcancel" class="btn btn-default" onclick="asd()" value="Change Password">
                </div>

                <div id="hideshow" style="display:none">
                     <div class="form-group">
                        <label for="op">Old Password:</label>
                        <input type="password" class="form-control" id="op" style="max-width:300px;" value="123456" disabled>
                    </div>
                     <div class="form-group">
                        <label for="np1">New Password:</label>
                        <input type="password" class="form-control" id="np1" style="max-width:300px;">
                    </div>
                     <div class="form-group">
                        <label for="np2">Confirm New Password:</label>
                        <input type="password" class="form-control" id="np2" style="max-width:300px;">
                    </div>
                   
                </div>

                    <hr>

                    
                    <div class="form-group">
                        <label for="addr">ေနရပ္လိပ္စာ :</label>
                        <input type="text" class="form-control" id="addr" style="max-width:500px;" value="No-4, Nyaung Pin Tha St.">
                    </div>
                    <div class="form-group">
                        <label for="ph">ဖုန္းနံပါတ္ :</label>
                        <input type="text" class="form-control" id="ph" style="max-width:300px;" value="09-794517433">
                    </div>
                   
                     <div class="form-group">
                        <label for="sel1">လိင္ :</label>
                            <select class="form-control" id="sel1" style="max-width:200px;">
                                <option selected>က်ား</option>
                                <option>မ</option>
                                <option>မထည့္ပါ</option>                                
                            </select>
                  	</div>
                  	<button type="submit" class="btn btn-default">ေျပာင္းလဲမည္</button>
                </form>
            </div>

    @endsection

@section('footer')
@parent
@endsection
