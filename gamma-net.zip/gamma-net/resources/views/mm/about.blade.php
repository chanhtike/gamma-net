@extends('layouts.mm-navbar')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
    @parent
    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Gamma Net ဆိုသည္မွာ
                    <small> ဘာလဲ ၊ ဘယ္လဲ ?</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="mm-index">Home</a>
                    </li>
                    <li class="active">About</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Intro Content -->
        <div class="row">
            <div class="col-md-6">
                <img class="img-responsive" src="img/gn_aboutus.png" alt="">
            </div>
            <div class="col-md-6">
                <h2>Gamma Net အေၾကာင္း</h2>
                <p>ကၽြႏု္ပ္တို႔ကုမၸဏီမွာ အသင္းဝင္ထားျခင္းျဖင့္ ေခတ္မွီအသံုးအေဆာင္မ်ား ဝယ္ယူႏိုင္ျခင္း၊ ဖုန္းေငြျဖည့္ကဒ္မ်ားကို လက္လီေစ်းျဖင့္ ဝယ္ယူႏုိင္ျခင္း၊ ႏိုင္ငံအႏွံ႔ ေငြလႊဲပို႔ႏိုင္ျခင္း၊ Bonus မ်ားရယူႏုိင္ျခင္း စတဲ့ အက်ိဳးေက်းဇူးမ်ား ရရွိႏုိင္မွာျဖစ္ပါတယ္။</p>
                <p>ကၽြႏု္ပ္တို႔ကုမၸဏီႏွင့္ လက္တြဲေဆာင္ရြက္ျခင္းအားျဖင့္ သင့္ဘဝလူေနမႈ အဆင့္အတန္းကို သိသိသာသာ တိုးတက္ေျပာင္းလဲ ေစမယ္လို႔ ရဲရဲႀကီးအာမခံပါတယ္၊ MultiLevel ေစ်းကြက္တစ္ခုထက္ပိုတဲ့ ရပ္ဝန္းတစ္ခုပါ</p>
                <p>ကၽြႏု္ပ္တို႔ ကုမၸဏီဟာ အျခားေသာ အြန္လိုင္း Website မ်ားထက္သာလြန္ေကာင္းမြန္ေအာင္ ႏိုင္ငံတကာ အဆင့္မွီဖန္တီးထားတဲ့အတြက္ လြယ္ကူရိုးရွင္းၿပီး လံုၿခံဳစိတ္ခ်ရပါတယ္။ ေန႔စဥ္ေန႔တိုင္း လြယ္ကူစြာ အသံုးျပဳႏိုင္ေအာင္ Mobile App ကိုပါဖန္တီးေပးထားပါတယ္။</p>
            </div>
        </div>
        <!-- /.row -->

        <!-- Team Members -->
        <div class="row">
            <div class="col-lg-12">
                <h2 class="page-header">ကၽြႏု္ပ္တို႔အဖြဲ႕</h2>
            </div>
            <div class="col-md-4 text-center">
                <div class="thumbnail">
                    <img class="img-responsive" src="img/admin.png" alt="">
                    <div class="caption">
                        <h3> မိုးသူရိန္<br>
                            <small>Director</small>
                        </h3>
                        <p>One of our founder and board of director. Phone : +95 9 66674633</p>
                        <ul class="list-inline">
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-facebook-square"></i></a>
                            </li>
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-linkedin-square"></i></a>
                            </li>
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-twitter-square"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4 text-center">
                <div class="thumbnail">
                    <img class="img-responsive" src="img/admin.png" alt="">
                    <div class="caption">
                        <h3>ေအာင္မ်ိဳးထြန္း <br>
                            <small>Director</small>
                        </h3>
                        <p>One of our founder and board of director. Phone : +95 9 794552064</p>
                        <ul class="list-inline">
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-facebook-square"></i></a>
                            </li>
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-linkedin-square"></i></a>
                            </li>
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-twitter-square"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4 text-center">
                <div class="thumbnail">
                    <img class="img-responsive" src="img/admin.png" alt="">
                    <div class="caption">
                        <h3>ေဝရန္ပိုင္ <br>
                            <small>Director</small>
                        </h3>
                        <p>One of our founder and board of director. Phone : +95 9 797787500</p>
                        <ul class="list-inline">
                           <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-facebook-square"></i></a>
                            </li>
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-linkedin-square"></i></a>
                            </li>
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-twitter-square"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4 text-center">
                <div class="thumbnail">
                    <img class="img-responsive" src="img/admin.png" alt="">
                    <div class="caption">
                        <h3>ေစာဇာနည္လြင္ <br>
                            <small>Director</small>
                        </h3>
                        <p>One of our founder and board of director. Phone : +95 9 965517407</p>
                        <ul class="list-inline">
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-facebook-square"></i></a>
                            </li>
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-linkedin-square"></i></a>
                            </li>
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-twitter-square"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4 text-center">
                <div class="thumbnail">
                    <img class="img-responsive" src="img/admin.png" alt="">
                    <div class="caption">
                        <h3>မင္းျပည့္စံု <br>
                            <small>Director</small>
                        </h3>
                        <p>One of our founder and board of director. Phone : +95 9 454449094</p>
                        <ul class="list-inline">
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-facebook-square"></i></a>
                            </li>
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-linkedin-square"></i></a>
                            </li>
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-twitter-square"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4 text-center">
                <div class="thumbnail">
                    <img class="img-responsive" src="img/admin.png" alt="">
                    <div class="caption">
                         <h3>Mr John <br>
                            <small>Technical Director</small>
                        </h3>
                        <p>One of our founder and board of director. Phone : +95 9 123456789</p>
                        <ul class="list-inline">
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-facebook-square"></i></a>
                            </li>
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-linkedin-square"></i></a>
                            </li>
                            <li><a href="http://www.facebook.com/gamma-net"><i class="fa fa-2x fa-twitter-square"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->

        <!-- Our Customers -->
        <div class="row">
            <div class="col-lg-12">
                <h2 class="page-header">Our Customers</h2>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive customer-img" src="img/customers.png" alt="">
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive customer-img" src="img/customers.png" alt="">
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive customer-img" src="img/customers.png" alt="">
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive customer-img" src="img/customers.png" alt="">
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive customer-img" src="img/customers.png" alt="">
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6">
                <img class="img-responsive customer-img" src="img/customers.png" alt="">
            </div>
        </div>
        <!-- /.row -->

        <hr>

        <!-- Footer -->
        @endsection
        <!-- Footer -->
@section('footer')
    
@parent

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

@endsection