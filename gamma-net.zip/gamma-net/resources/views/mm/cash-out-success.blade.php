@extends('layouts.mm-member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
 			
 			<div class="col-md-9">
                <h2>ေငြထုတ္ျခင္းလုပ္ငန္းေအာင္ျမင္ပါသည္</h2>
                <p>ေငြက်ပ္ <b>xxx</b> ထုတ္ၿပီးေနာက္ သင္၏လက္က်န္ေငြ မွာ <b>xxx</b> က်ပ္ျဖစ္ပါသည္</p>
                <p>သင္၏ဘဏ္အေကာင့္ထဲသို႔ ၃ နာရီအတြင္းေငြမ်ားေျပာင္းလဲေရာက္ရွိမည္ျဖစ္ပါသည္</p>
                <p>ကၽြႏ္ုပ္တို႔၏ဝန္ေဆာင္မႈကို အသံုးျပဳသည့္အတြက္အထူးေက်းဇူးတင္ရွိပါသည္။</p>
            </div>

    @endsection

@section('footer')
@parent
@endsection
