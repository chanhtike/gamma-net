@extends('layouts.mm-member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
 			
 			<div class="col-md-9">
                <h2>ဖုန္းေငြျဖည့္ကတ္ဒ္ ဝယ္ရန္</h2>
                <p>Gamma-Net အေကာင့္ျဖင့္ ဖုန္းေငြျဖည့္ကတ္ဒ္မ်ားလြယ္ကူစြာဝယ္ယူႏိုင္ပါသည္</p>
                <p><b>Gamma-Net အေကာင့္ျဖင့္ ဖုန္းေငြျဖည့္ကတ္ဒ္ဝယ္ယူျခင္းျဖင့္ Bonus အမွတ္မ်ားရယူလိုက္ပါ။</b></p>
                <form role="form" action="mm-member-topup-confirm">
                	<div class="form-group">
                        <label for="email">သင့္အီးေမးလ္ :</label>
                        <input type="text" class="form-control" id="email" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="pass">သင့္လွ်ိဳ႕ဝွက္နံပါတ္ :</label>
                        <input type="password" class="form-control" id="pass" style="max-width:300px;">
                    </div>
                   
                    <div class="form-group">
                        <label for="sel1">တယ္လီဖုန္းကုမၸဏီေရြးပါ :</label>
                            <select class="form-control" id="sel1" style="max-width:200px;">
                                <option>Telenor</option>
                                <option>MPT</option>
                                <option>Ooredoo</option>
                                 <option>MecTel</option>
                            </select>
                    </div>
                    <div class="form-group">
                        <label for="sel1">ဝယ္ယူလိုသည့္ေငြပမာဏ:</label>
                            <select class="form-control" id="sel1" style="max-width:200px;">
                                <option>1000-MMK</option>
                                <option>3000-MMK</option>
                                <option>5000-MMK</option>
                                <option>10000-MMK</option>
                            </select>
                    </div>
                    
                    <div class="checkbox">
                        <label><input type="checkbox"> ဖုန္းေငြျဖည့္ကဒ္ဝယ္ယူျခင္းျဖင့္ Bonus ရယူရန္ေသခ်ာပါသည္။</label>
                    </div>
                     <button type="submit" class="btn btn-default">ဝယ္မည္</button>
                </form>
            </div>

    @endsection

@section('footer')
@parent
@endsection


