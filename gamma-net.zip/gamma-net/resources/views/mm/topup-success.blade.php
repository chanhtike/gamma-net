@extends('layouts.mm-navbar')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
    @parent

    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">ဖုန္းေငြျဖည့္ကတ္ဒ္ ဝယ္ရန္
                    <small>ဖုန္းေငြျဖည့္ကတ္ဒ္ ဝယ္ရန္</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index">ပင္မစာမ်က္ႏွာ</a>
                    </li>
                    <li class="active">ဖုန္းေငြျဖည့္ကတ္ဒ္ ဝယ္ပါ</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Content Row -->
        <div class="col-md-9">
                <h2>ေငြျဖည့္ကဒ္ဝယ္ယူျခင္းလုပ္ငန္းစဥ္ေအာင္ျမင္ပါသည္</h2>
                <p>သင္ဝယ္ယူထားေသာကတ္ဒ္ : <b>Telenor - 10000-MMK</b></p>
                <p>ေငြျဖည့္ကုတ္ဒ္နံပါတ္ : <b>1234 5678 9123 1234</b></p>
                
                <p>သင္၏ Gamma-Net လက္က်န္ေငြမွာ  : <b> xxxx</b> Ks </p>
                <p>ကြ်ႏု္ပ္တို႔ဝန္ေဆာင္မႈမ်ားကိုအသံုးျပဳျခင္းအတြက္အထူးေက်းဇူးတင္ရွိပါသည္။</p>
            </div>
        <!-- /.row -->

        <hr>

        <!-- Footer -->
        @endsection
        <!-- Footer -->
@section('footer')
    
@parent

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

@endsection