@extends('layouts.mm-member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
    @parent
            
            <div class="col-md-9">
                <h2>ဤေငြျဖည့္ကတ္ဒ္ကို ဝယ္ယူရန္ေသခ်ာပါသလား</h2>
               <p>အမ်ိဳးအစား : <b>Telenor</b></p>
                <p>ေငြပမာဏ : <b>10000-MMK</b></p>
                <form role="form" action="mm-member-topup-success">
                    <div class="checkbox">
                        <label><input type="checkbox"> အထက္ပါအခ်က္အလက္မ်ားအားလံုးမွန္ကန္ပါသည္</label>
                    </div>
                     <button type="submit" class="btn btn-default">ဝယ္ရန္ေသခ်ာပါသည္</button>
                </form>
            </div>

    @endsection

@section('footer')
@parent
@endsection


