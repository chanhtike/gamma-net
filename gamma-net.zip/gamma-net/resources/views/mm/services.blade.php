@extends('layouts.mm-navbar')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
    @parent

    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">ကၽြႏု္ပ္တို႔၏ဝန္ေဆာင္မႈမ်ား
                    <small>Subheading</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="mm-index">Home</a>
                    </li>
                    <li class="active">ဝန္ေဆာင္မႈမ်ား</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Content Row -->
         <div class="row">
            <div class="col-lg-12">
                <img class="img-responsive" src="img/services.png" alt="">
            </div>
        </div>
        <!-- /.row -->

        <!-- Service Panels -->
        <!-- The circle icons use Font Awesome's stacked icon classes. For more information, visit http://fontawesome.io/examples/ -->
        <div class="row">
            <div class="col-lg-12">
                <h2 class="page-header">Gamma-Net ၏ ဝန္ေဆာင္မႈမ်ား</h2>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="panel panel-default text-center">
                    <div class="panel-heading">
                        <span class="fa-stack fa-5x">
                              <i class="fa fa-circle fa-stack-2x text-primary"></i>
                              <i class="fa fa-tree fa-stack-1x fa-inverse"></i>
                        </span>
                    </div>
                    <div class="panel-body">
                        <h4>အသင္းဝင္ျခင္း</h4>
                        <p>Gamma-Net တြင္ အသင္းဝင္ ထားျခင္းျဖင့္ bonus မ်ား ဆုေၾကးေငြ မ်ားရယူရင္း အနာဂါတ္ကို တည္ေဆာက္ လိုက္ပါ</p>
                        <a href="mm-pricing" class="btn btn-primary">ေလ့လာမယ္</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="panel panel-default text-center">
                    <div class="panel-heading">
                        <span class="fa-stack fa-5x">
                              <i class="fa fa-circle fa-stack-2x text-primary"></i>
                              <i class="fa fa-car fa-stack-1x fa-inverse"></i>
                        </span>
                    </div>
                    <div class="panel-body">
                        <h4>ေစ်းဝယ္ျခင္း</h4>
                        <p>အြန္လိုင္းမွာ ေစ်းဝယ္ရျခင္းကို ႏွစ္ၿခိဳက္သူမ်ား အတြက္ Gamm-Net အေကာင့္ ျဖင့္ျဖစ္ေစ MPU e-Commerce ျဖင့္ျဖစ္ေစ ေစ်းဝယ္ႏိုင္ပါၿပီ</p>
                        <a href="mm-shopping" class="btn btn-primary">ေလ့လာမယ္</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="panel panel-default text-center">
                    <div class="panel-heading">
                        <span class="fa-stack fa-5x">
                              <i class="fa fa-circle fa-stack-2x text-primary"></i>
                              <i class="fa fa-support fa-stack-1x fa-inverse"></i>
                        </span>
                    </div>
                    <div class="panel-body">
                        <h4>ဖုန္းေဘလ္ဝယ္ျခင္း</h4>
                        <p>ဖုန္းေငြျဖည့္ကဒ္ေလးမ်ား အေရးေပၚလိုအပ္ေနပါသလား Gamma-Net မွာ အခုပဲ သက္သာေသာ ေစ်းႏႈန္းျဖင့္ Prepaid Card မ်ား ဝယ္ယူႏိုင္ပါၿပီ</p>
                        <a href="mm-topup" class="btn btn-primary">ေလ့လာမယ္</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="panel panel-default text-center">
                    <div class="panel-heading">
                        <span class="fa-stack fa-5x">
                              <i class="fa fa-circle fa-stack-2x text-primary"></i>
                              <i class="fa fa-database fa-stack-1x fa-inverse"></i>
                        </span>
                    </div>
                    <div class="panel-body">
                        <h4>ေငြလႊဲျခင္း</h4>
                        <p>ႏိုင္ငံအႏွံ႔သို႔ Gamma-Net အေကာင့္ျဖင့္ျဖစ္ေစ MPU E-Commerce ျဖင့္ျဖစ္ေစ သက္သာစြာျဖင့္ ေငြလႊဲထုတ္ႏိုင္ပါၿပီ</p>
                        <a href="mm-remit" class="btn btn-primary">ေလ့လာမယ္</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->

        <hr>

        <!-- Footer -->
       @endsection
        <!-- Footer -->
@section('footer')
    
@parent
    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Contact Form JavaScript -->
    <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

@endsection