@extends('layouts.mm-navbar')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
    @parent

    <!-- Page Content -->
     <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">ဂုဏ္ယူပါတယ္
                    <small>Confirm Code မွန္ကန္ပါသည္</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index">ပင္မစာမ်က္ႏွာ</a>
                    </li>
                    <li class="active">မွတ္ပံုတင္ျခင္းလုပ္ငန္းစဥ္ေအာင္ျမင္ပါသည္</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Content Row -->
        <div class="row">
            <div class="col-lg-12">
                <p>သင္၏ မွတ္ပံုတင္ျခင္းလုပ္ငန္းစဥ္ေအာင္ျမင္ပါသည္ သင့္ကိုယ္ပိုင္စာမ်က္ႏွာသို႔သြားႏိုင္ပါၿပီ</p>
                 <a href="mm-member-home" class="btn btn-primary">ကိုယ္ပိုင္စာမ်က္ႏွာသို႔သြားမည္</a>
            </div>
        </div>
        <!-- /.row -->

        <hr>


        <!-- Footer -->
        @endsection
        <!-- Footer -->
@section('footer')
    
@parent

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

@endsection