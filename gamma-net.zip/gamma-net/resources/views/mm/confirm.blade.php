@extends('layouts.mm-navbar')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
    @parent

    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">အသင္းဝင္မည္
                    <small>Confirm ျပဳလုပ္မည္</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index">ပင္မစာမ်က္ႏ်ာ</a>
                    </li>
                    <li class="active">Email Confirm ျပဳလုပ္ျခင္း</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Content Row -->
        <div class="row">
            <div class="col-lg-12">
                <p>သင့္ေမးထဲသို႔ ေပးပို႔ထားေသာ Confirm Code ရုိက္ထည့္ေပးပါ</p>
                 <form role="form" action="mm-success">
                    <div class="form-group">
                        <label for="confirm">Confirmation Code ရုိက္ထည့္ေပးပါ:</label>
                        <input type="text" class="form-control" id="confirm" style="max-width:300px;">
                    </div>
                    
                    <button type="submit" class="btn btn-default">မွတ္ပံုတင္မည္</button>
                </form>
            </div>
        </div>
        <!-- /.row -->

        <hr>

        <!-- Footer -->
        @endsection
        <!-- Footer -->
@section('footer')
    
@parent

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

@endsection