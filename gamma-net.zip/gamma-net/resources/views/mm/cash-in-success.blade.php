@extends('layouts.mm-member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
 			
 			<div class="col-md-9">
                <h2>ေငြသားေပးသြင္းျခင္း လုပ္ငန္းစဥ္ ေအာင္ျမင္ပါသည္</h2>
                <p><b>xxx</b> မိနစ္အတြင္း သင္၏ေငြလက္က်န္မွာ <b>xxx</b> က်ပ္ျဖစ္လာပါလိမ့္မည္။</p>
                <p>ကၽြႏ္ုပ္တို႔၏ဝန္ေဆာင္မႈကို အသံုးျပဳသည့္အတြက္အထူးေက်းဇူးတင္ရွိပါသည္။</p>
            </div>

    @endsection

@section('footer')
@parent
@endsection


