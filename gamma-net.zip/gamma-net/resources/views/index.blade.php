@extends('layouts.navbar')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
    @parent

    <!-- Page Content -->
    <header id="myCarousel" class="carousel slide">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner">
            <div class="item active">
                <div class="fill" style="background-image:url('img/gn_slider1.png');"></div>
                <div class="carousel-caption">
                    <h2>Grow up Richer!!</h2>
                </div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('img/gn_slider2.png');"></div>
                <div class="carousel-caption">
                    <h2>Be a Leader!!</h2>
                </div>
            </div>
            <div class="item">
                <div class="fill" style="background-image:url('img/gn_slider3.png');"></div>
                <div class="carousel-caption">
                    <h2>Enjoy Your Shopping!!</h2>
                </div>
            </div>
        </div>

        <!-- Controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>
    </header>

    <!-- Page Content -->
        <div class="container">

            <!-- Marketing Icons Section -->
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">
                        Hello! Welcome to Gamma-Net
                    </h2>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4><i class="fa fa-fw fa-check"></i> You Can Register at Gamma-Net Now</h4>
                        </div>
                        <div class="panel-body">
                            <p>You can get money remit services, online shopping services, Mobile top-up services, cash bonus benefits by registering on Gamma-net Right Now!!</p>
                            <a href="pricing" class="btn btn-default">Learn More</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4><i class="fa fa-fw fa-gift"></i> Better than other competitors</h4>
                        </div>
                        <div class="panel-body">
                            <p>Gamma-Net is more than a Multi-Level Marketing because you can get many discounts, benefits and more profits by joining us, we can upgrade your life style</p>
                            <a href="pricing" class="btn btn-default">Learn More</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4><i class="fa fa-fw fa-compass"></i>Get the FREEDOM!</h4>
                        </div>
                        <div class="panel-body">
                            <p>100 % Free technology usage, 100 % Cash and income usage, 100 % Time usage plans you can get now! So, enjoy Gamma-net to get 100% successful life. 
                            </p>
                        <a href="pricing" class="btn btn-default">Learn More</a>
                    </div>
                </div>
            </div>
        
        <!-- /.row -->

        <!-- Portfolio Section -->
        <div class="row">
            <div class="col-lg-12">
                <h2 class="page-header">Our Services for You!</h2>
            </div>
            <div class="col-md-4 col-sm-6">
                <a href="pricing">
                    <img class="img-responsive img-portfolio img-hover" src="img/gn_act1.png" alt="">
                        <div class="carousel-caption">
                            <h3 color="blue">Register</h3>
                        </div>
                </a>
            </div>
            <div class="col-md-4 col-sm-6">
                <a href="shopping">
                    <img class="img-responsive img-portfolio img-hover" src="img/gn_act2.png" alt="">
                    <div class="carousel-caption">
                            <h3 color="blue">Online Shopping</h3>
                        </div>
                </a>
            </div>
            <div class="col-md-4 col-sm-6">
                <a href="topup">
                    <img class="img-responsive img-portfolio img-hover" src="img/gn_act3.png" alt="">
                    <div class="carousel-caption">
                            <h3 color="blue">Phone Bill Topup</h3>
                        </div>
                </a>
            </div>
            <div class="col-md-4 col-sm-6">
                <a href="remit">
                    <img class="img-responsive img-portfolio img-hover" src="img/gn_act4.png" alt="">
                    <div class="carousel-caption">
                            <h3 color="blue">Money Transfer</h3>
                        </div>
                </a>
            </div>
            <div class="col-md-4 col-sm-6">
                <a href="pricing">
                    <img class="img-responsive img-portfolio img-hover" src="img/gn_act5.png" alt="">
                    <div class="carousel-caption">
                            <h3 color="blue">Get Bonuses!</h3>
                        </div>
                </a>
            </div>
            <div class="col-md-4 col-sm-6">
                <a href="pricing">
                    <img class="img-responsive img-portfolio img-hover" src="img/gn_act6.png" alt="">
                    <div class="carousel-caption">
                            <h3 color="blue">Find Cash!</h3>
                        </div>
                </a>
            </div>
        </div>
        <!-- /.row -->

        <!-- Features Section -->
        <div class="row">
            <div class="col-lg-12">
                <h2 class="page-header">Why do we need to register Gamma-Net?</h2>
            </div>
            <div class="col-md-6">
                <p>Gamma-Net Co., ltd သည္ ေဒသတြင္းေရွ႕ေဆာင္အျဖစ္ လ်င္ျမန္စြာႀကီးထြားလာခဲ့ၿပီး ယေန႔အခ်ိန္တြင္ အမယ္ေပါင္းစံု က်ယ္ျပန္႔စြာပါဝင္သည့္ ထိပ္တန္းလူသံုးကုန္ပစၥည္းမ်ား၊ ဖြံ႕ၿဖိဳးတိုးတက္မႈ၊ ထုတ္လုပ္မႈ၊ ေစ်းကြက္ေဖာ္ေဆာင္ဖန္တီးမႈ မ်ားတြင္ တက္ႂကြစြာ လုပ္ေဆာင္လ်က္ရွိၿပီး ျမန္မာႏိုင္ငံတြင္ ေအာင္ျမင္သည့္ စီးပြားေရးေမာ္ဒန္ (modern) တစ္ခုကို မိတ္ဆက္ေပးႏိုင္ခဲ့ၿပီး ႀကိဳးပမ္းမႈျဖင့္ အထြတ္အထိပ္ကို ေရာက္ရွိေနပါၿပီ။
                ယေန႔၌ Gamma-Net သည္ ျမန္မာႏိုင္ငံတြင္ လၽွင္ျမန္စြာ ႀကီးထြားလ်က္ရွိၿပီး တိုးတက္ႀကီးထြားမႈ အလ်င္ျမန္ဆံုး စီးပြားေရးႏွင့္ဝန္ေဆာင္မႈ ကုမၸဏီမ်ားထဲမွတစ္ခုျဖစ္ေနပါသည္။
                အကန္႔အသတ္မဲ့ ၿပီးေျမာက္ေအာင္ျမင္မႈတို႔ျဖင့္ အတိၿပီးသည့္ ေတာက္ပသည့္အနာဂတ္ကို ေဖာ္ေဆာင္ေပးရန္အတြက္ Gamma-Net သည္ တက္ႂကြလႈပ္ရွားေသာေခါင္းေဆာင္မႈႏွင့္ တစ္ကိုယ္ေရဖြံ႕ၿဖိဳးတိုးတက္မႈသင္တန္း၊ စြမ္းရည္ျမင့္အသက္ေမြးဝမ္းေၾကာင္းအလုပ္အကိုင္တည္ေထာင္မႈႏွင့္ အျခားအခြင့္အလမ္းမ်ားအတြက္ အားေပးျမႇင့္တင္ျခင္းတို႔ကို ျပဳလုပ္ေဆာင္ရြက္ေပးလ်က္ရွိၿပီး၊ ပိုမိုေကာင္းမြန္စြာေဆာင္ရြက္ေပးႏိုင္ရန္လည္း ႀကိဳးစားလ်က္ရွိပါသည္။
                Gamma-Net ကုမၸဏီ၏ ေတာက္ပသည့္ စီးပြားေရးလုပ္ငန္းေဆာင္ရြက္မႈ လမ္းညႊန္ခ်က္မ်ားသည္ ၿပိဳင္ဘက္ကင္းေသာ ေအာင္ျမင္မႈလမ္းေၾကာင္းဆီသို႔ သင့္ကိုလမ္းညႊန္ျပသေပးႏိုင္ရန္အတြက္ အထူးျပဳၿပီး ေတာက္ပေသာ ေအာင္ျမင္မႈႏွင့္ အံ့ခ်ီးဖြယ္ၿပီးေျမာက္မႈကို အတိၿပီးသည့္ အနာဂတ္အတြက္ ေသခ်ာမုခ်ေအာင္ျမင္မႈရေစရန္ သင္၏အရိုင္းသက္သက္ စိတ္ကူးေမၽွာ္မွန္းခ်က္မ်ားကို ရုပ္လံုးေဖာ္ေပးမည့္ ေသာ့ခ်က္နည္းလမ္းမ်ားကို ပံ့ပိုးလမ္းညႊန္ေပးထားပါသည္။
                </p>
                
            </div>
            <div class="col-md-6">
                <img class="img-responsive" src="img/gn_joinnow.png" alt="">
            </div>
        </div>
        <!-- /.row -->

        <hr>

        <!-- Call to Action Section -->
        <div class="well">
            <div class="row">
                <div class="col-md-8">
                    <p>Please Contact to Gamma-Net to get the latest services and promotions!!</p>
                </div>
                <div class="col-md-4">
                    <a class="btn btn-lg btn-default btn-block" href="contact">Call to Action</a>
                </div>
            </div>
        </div>
        <!-- /.row -->

        <hr>

        <!-- Footer -->
       @endsection
        <!-- Footer -->
@section('footer')
    
@parent
    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Contact Form JavaScript -->
    <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>
    <script>
    $('.carousel').carousel({
        interval: 5000 //changes the speed
    })
    </script>
@endsection