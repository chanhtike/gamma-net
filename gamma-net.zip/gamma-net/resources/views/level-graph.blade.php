@extends('layouts.member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
 			
 			<div class="col-md-9">
                <h2>This is your level and downline</h2>
                <p>Now your Level is : <b>Platinum</b></p>
                <p>Your Bonus is : <b>xxxxxx</b> Ks per Month</p>
                <div style="width:95%; height:100%; overflow:auto; padding:5px;">
                <div class="tree" style="width: 600px; height:300px;">
					<ul>
						<li>
							<a href="#">Diamiond</a>
								<ul>
									<li>
										<a href="#">Platinum</a>
											<ul>
												<li>
													<a href="#">Gold</a>
														<ul>
															<li>
																<a href="#">Silver</a>
															</li>
															<li>
																<a href="#">Silver</a>
															</li>
														</ul>
												</li>
												<li>
													<a href="#">Gold</a>
														<ul>
															<li>
																<a href="#">Silver</a>
															</li>
															<li>
																<a href="#">Silver</a>
															</li>
														</ul>
												</li>
											</ul>
									</li>
									<li>
										<a href="#">Platinum</a>
											<ul>
												<li>
													<a href="#">Gold</a>
														<ul>
															<li>
																<a href="#">Silver</a>
															</li>
															<li>
																<a href="#">Silver</a>
															</li>
														</ul>
												</li>
												<li>
													<a href="#">Gold</a>
														<ul>
															<li>
																<a href="#">Silver</a>
															</li>
															<li>
																<a href="#">Silver</a>
															</li>
														</ul>
												</li>
											</ul>
									</li>
								</ul>					
						</li>
					</ul>
				</div>
				</div>
            </div>


    @endsection

@section('footer')
@parent
@endsection


