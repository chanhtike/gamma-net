@extends('layouts.member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
    @parent
            
            <div class="col-md-9">
                <h2>Are you sure to buy this topup card</h2>
               <p>Your preferred Telecom : <b>Telenor</b></p>
                <p>Your Preferred Amount : <b>10000-MMK</b></p>
                <form role="form" action="member-topup-success">
                    <div class="checkbox">
                        <label><input type="checkbox"> All data I've chosen above are Right!</label>
                    </div>
                     <button type="submit" class="btn btn-default">Confirm</button>
                </form>
            </div>

    @endsection

@section('footer')
@parent
@endsection


