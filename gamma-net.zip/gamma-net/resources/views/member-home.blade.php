@extends('layouts.member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
 			
 			<div class="col-md-9" >
            
                <h2>This is My Personal Profile</h2>
                
                <p>Welcome to Gamm-net User Area, you can now use variety of our services.</p>
                <img src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=GN1234&nbsp;:&nbsp;Chan&nbsp;Htike" title="Link to Google.com" />
                 <p>ID: <b>GN1234</b></p>
                <p>Name: <b>Chan Htike</b></p>
                <p>Address: <b>No.4, Zay Chaung St, Pathein</b></p>
                <p>Phone Number: <b>09-794517433</b></p>
                <p>Email: <b><u>gn-user@gamma-net.com</u></b></p>
            
            </div>

    @endsection

@section('footer')
@parent
@endsection


