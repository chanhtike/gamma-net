@extends('layouts.navbar')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
    @parent
    <!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Register Now!
                    <small>Subheading</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index">Home</a>
                    </li>
                    <li class="active">Membership Plan</li>
                </ol>
              
            </div>
        </div>
        <!-- /.row -->

        <!-- Content Row -->
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default text-center">
                    <div class="panel-heading">
                        <h3 class="panel-title">Premium Member</h3>
                    </div>
                    <div class="panel-body">
                        <span class="price"><sup>Ks</sup>5<sup>000</sup></span>
                        <span class="period">minimum per month</span>
                    </div>
                    <ul class="list-group">
                        <li class="list-group-item"><strong>1</strong> User</li>
                        <li class="list-group-item"><strong>Ks 20,000</strong> Member Fees</li>
                        <li class="list-group-item"><strong>1</strong> Member Account</li>
                        <li class="list-group-item"><strong>Ks 5,000</strong> Minimal buy per month</li>
                        <li class="list-group-item"><h4><strong>ks 25,000</strong>: Total Only</li></h4>
                        <li class="list-group-item"><a href="reg-page" class="btn btn-primary">Sign Up!</a>
                        </li>
                    </ul>
                </div>
            </div>
            
           
            

        </div>
        <!-- /.row -->
        <h2>Gamma-Net နဲ႔ပူးေပါင္းၿပီး သင့္ဖုန္းထဲမွာ Market တစ္ခုထူေထာင္ရင္း BMW တစ္စီးခုပဲရယူ ပိုင္ဆိုင္နိဳင္ပါၿပီ ။</h2>
        <hr>
        <h1>Gamma-Net ႏွင့္ပူးေပါင္းၿပီး ဂ်ပန္သို႔ Free လည္ ပတ္ခြင့္ရႏိုင္မယ့္ အခြင့္အေရးတစ္ခု သင့္လက္တစ္ ကမ္းမွာ႐ွိေနပါၿပီ။</h1>
        <hr>
        
        <h4><b>ဟယ္လို .... ႏိုဝင္ဘာ ...</b></h4>
        <p>
ကဲ .... တစ္ေလေျပာင္းျပန္ၿပီ။ လူႀကီးမင္းတို႔ဘဝေတြေရာ ေျပာင္းလဲခဲ့ၿပီလား... က်န္ခဲ့တဲ့လကထုတ္ထားတဲ့ လစာေလးကို အိမ္စရိတ္၊ ထြက္ေငြ၊ ကိုယ့္အသံုးေငြ၊ တစ္ျခားထြက္ေငြေတြၾကားထဲမွာ အဆင္ေျပေအာင္ဘယ္လို Plan ခ်ရမယ္ဆိုတာ စဥ္းစားရင္း ေခါင္းရွဳပ္ေနတယ္....
ဟုတ္တယ္ဟုတ္ ...
ဒီအခက္အခဲေတြအားလံုးကို ေက်ာ္လႊားႏိုင္ဖို႔ လူႀကီးမင္းတို႔ရဲ႕အနားမွာ Gamma Net ရွိေနပါၿပီ။
ယခုလက္ရွိလုပ္ေနက်ေတြကိုလည္း စြန္႔လႊတ္စရာမလိုဘူး။ သီးသန္႔အခ်ိန္ေတြကိုလည္း ေပးစရာမလိုဘူး။ ဒါေပမယ့္ လစဥ္သိန္းေပါင္းေျမာက္ျမားစြာ ဝင္ေငြရွိေနမယ္... ဘယ္လိုလုပ္ရမလဲ...?
ခုပဲ Gamma Net နဲ႔ ပူးေပါင္းလိုက္ပါ...။။။။

        </p>
        <hr>
        <h3>Company'a Registration</h3>
        <p>
        ကုမၸဏီမ်ား အက္ဥပေဒ အရ အသိအမွတ္ျပဳ မွတ္ပံုတင္လက္မွတ္ရ႐ွိထားၿပီျဖစ္ေသာေၾကာင့္ 
Gamma-Net ႏွင့္အတူလုပ္ငန္းေဆာင္တာမ်ား အားယံုၾကည္စိတ္ခ်စြာျဖင့္ ေရ႐ွည္လက္တြဲလုပ္ ေဆာင္ႏိုင္ၾကမည္ျဖစ္ပါသည္။
Gamma-Net တြင္တစ္ႀကိမ္ Register လုပ္ထားရံု ျဖင့္ တစ္သက္တာအိမ္အေရာက္ပို႔ Delivery ျဖင့္ မည္သည့္ပစၥည္းကိုမဆို ေစ်းႏႈန္းခ်ိဳသာစြာ ဝယ္ယူ ရ႐ွိႏိုင္ပါၿပီ ။<br>
Gamma-Net မွဝယ္ယူထားေသာကုန္ပစၥည္းမ်ား ကိုအိမ္အေရာက္ပို႔ေဆာင္ေပးၿပီး ဝယ္ယူသူစိတ္ တိုင္းက်လက္မွတ္ထိုးလက္ခံေပးမွသာ Gamma -Net မွသက္ဆိုင္ရာမ်ားသို႔ေငြေပးေခ်မည္ျဖစ္ေသာ ေၾကာင့္ကုန္ပစၥည္းအေရအေသြးႏွင့္အေရအတြက္ ေငြေၾကးဆိုင္ရာလံုျခံဳမႈ ့မ်ားကိုထိမ္းခ်ဳပ္ထားၿပီး ျဖစ္ပါသည္။ေရာင္းခ်သည့္ပစၥည္းမ်ားမွာအမ်ိဳးအ စားစံုလင္လွၿပီး အမ်ားျပည္သူတိုင္းသံုးစြဲေနၾက ေသာဖုန္းေဘလ္အပါအဝင္ အမွန္တကယ္လိုအပ္ ေသာကုန္ပစၥည္းမ်ားျဖစ္ပါသည္။<br>
ကုန္ပစၥည္းေရာင္းခ်လိုသူမ်ားသည္ပစၥည္းပို႔ခအၿပီး အစီး 10 % ေကာ္မ႐ွင္ေပး၍ေရာင္းခ်ႏိုင္ပါသည္။<br>
စားေသာက္ဆိုင္ ၊ Travel and Tour လုပ္ငန္းမ်ားကဲ့ သို႔ ဝန္ေဆာင္မႈ ့လုပ္ငန္းမ်ားလည္း အလ်ွင္အျမန္
ေရာင္းအားတက္လာရန္ Gamma-Net ႏွင့္ခ်ိတ္ ဆက္ထားႏိုင္ပါသည္ ။<br>
Register လုပ္ထားသူမ်ားအေနနဲ႔ ဒီလိုေကာင္းမြန္ တဲ့စနစ္ေတြနဲ႔တဟုန္ထိုးေအာင္ျမင္လာတဲ့  Gamma-Net E-Commerce ကိုမိတ္ေဆြႏွစ္ဦး အားမ်ွေဝျခင္းျဖင့္ Gamma-Net ၏ရာသက္ပန္ Partner အျဖစ္ခံယူၿပီး တစ္သက္တာ Delivery အျပင္လစဥ္ဝင္ေငြေထာင္ဂဏန္းမွက်ပ္သိန္းေပါင္း ေထာင္ခ်ီအထိေကာ္မ႐ွင္ခံစားခြင့္က႐ွိႏိုင္မည့္အခြင့္ အေရးျဖစ္ပါသည္။<br>
နယ္မွ Register ျပဳလုပ္လိုသူမ်ားလည္း Online မွျပဳလုပ္ႏိုင္ပါသည္။
        </p>

        <hr>
            <h3>စတင္ျခင္းႏွင့္ေအာင္ျမင္မႈ ့အတြက္မ႐ွိမျဖစ္ လိုအပ္ေသာ လက္နက္မ်ား</h3>
            <ol type="1">
                <li> Audio , CD , VCD , DVD
                <li>Gamma-Net Application
                <li>Gamma System မွခ်မွတ္ထားေသာ လမ္းၫႊန္စာအုပ္ႏွင့္အျခားစာအုပ္မ်ား
                <li> သင္တန္းမ်ား
            </ol>
            <p>ဒီ(4)ခ်က္ကိုသင္ပိုင္ႏိုင္စြာအသံုးခ်မယ္ဆိုရင္ အျမန္ဆံုးသင္ေအာင္ျမင္ႏိုင္ပါတယ္။</p>
        <hr>
           


        <!-- Footer -->
       @endsection
        <!-- Footer -->
@section('footer')
    
@parent

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

@endsection
