@extends('layouts.member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
 			
 			<div class="col-md-9">
                <h2>Cash out Process Successful</h2>
                <p>Your balance will be <b>xxx</b> Ks after withdrawl <b>xxx</b> Ks from your A/C </p>
                <p>Your cash will be transferred within 3 hours</p>
                <p>Thank's for using our services</p>
            </div>

    @endsection

@section('footer')
@parent
@endsection
