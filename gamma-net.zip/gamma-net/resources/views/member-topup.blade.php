@extends('layouts.member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
 			
 			<div class="col-md-9">
                <h2>Buy Prepaid Topup Card</h2>
               <p>You can now easily buy mobile topup prepaid cards by Gamma-Net Account</p>
                <p><b>You will get bonus mark form buying topup card by Gamma-Net Account</b></p>
                <form role="form" action="member-topup-confirm">
                	<div class="form-group">
                        <label for="email">Your Email :</label>
                        <input type="text" class="form-control" id="email" style="max-width:300px;">
                    </div>
                    <div class="form-group">
                        <label for="pass">Your Password :</label>
                        <input type="password" class="form-control" id="pass" style="max-width:300px;">
                    </div>
                   
                    <div class="form-group">
                        <label for="sel1">Choose Telecom :</label>
                            <select class="form-control" id="sel1" style="max-width:200px;">
                                <option>Telenor</option>
                                <option>MPT</option>
                                <option>Ooredoo</option>
                                 <option>MecTel</option>
                            </select>
                    </div>
                    <div class="form-group">
                        <label for="sel1">Choose Amount :</label>
                            <select class="form-control" id="sel1" style="max-width:200px;">
                                <option>1000-MMK</option>
                                <option>3000-MMK</option>
                                <option>5000-MMK</option>
                                <option>10000-MMK</option>
                            </select>
                    </div>
                    
                    <div class="checkbox">
                        <label><input type="checkbox"> I am sure to buy top up card from my Gamma-Net Cash.</label>
                    </div>
                     <button type="submit" class="btn btn-default">Next</button>
                </form>
            </div>

    @endsection

@section('footer')
@parent
@endsection


