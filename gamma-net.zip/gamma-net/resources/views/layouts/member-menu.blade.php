@extends('layouts.navbar')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
    @parent

    <!-- Page Content -->
     <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Member area
                    <small>Your Personal Page</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index">Personal Page</a>
                    </li>
                    <li class="active">You can now use our services</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Content Row -->
         <div class="row">
            <!-- Sidebar Column -->
            <div class="col-md-3">
                <div class="list-group">
                    <a href="member-home" class="list-group-item">My Profile</a>
                    <a href="PassForBalance" class="list-group-item">My Balance</a>
                    <a href="last-trans" class="list-group-item">Last Transitions</a>
                    <a href="level-graph" class="list-group-item">My Downline</a>
                    <a href="cash-in" class="list-group-item">Cash in</a>
                    <a href="cash-out" class="list-group-item">Cash out</a>
                    <a href="remit" class="list-group-item">Money transfer</a>
                    <a href="shopping" class="list-group-item">Shopping</a>
                    <a href="member-topup" class="list-group-item">Buy Mobile Prepaid-Topup</a>
                    <a href="user-guide" class="list-group-item">User Guide</a>
                    <a href="monthly-mark" class="list-group-item">Monthly Mark</a>
                    <a href="user-annoucement" class="list-group-item">User Annoucement</a>
                    <a href="inbox" class="list-group-item">Inbox</a>
                    <a href="ac-settings" class="list-group-item">Account Setting</a>
                   
                </div>
            </div>
            <!-- Content Column -->
            @show

       


        <!-- Footer -->
        @endsection
        <!-- Footer -->
@section('footer')
</div>
        <!-- /.row -->
        <hr/>
    
@parent

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

@endsection