@extends('layouts.mm-navbar')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
    @parent

    <!-- Page Content -->
     <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">အသင္းဝင္စာမ်က္ႏွာ
                    <small>ကၽြႏု္ပ္၏ကိုယ္ပိုင္စာမ်က္ႏွာ</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index">ကိုယ္ပိုင္စာမ်က္ႏွာ</a>
                    </li>
                    <li class="active">ကၽြႏု္ပ္တို႔၏ အထူးဝန္ေဆာင္မႈမ်ားကို စတင္အသံုးျပဳႏိုင္ပါၿပီ</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Content Row -->
         <div class="row">
            <!-- Sidebar Column -->
            <div class="col-md-3">
                <div class="list-group">
                    <a href="mm-member-home" class="list-group-item">ကိုယ္ေရးအခ်က္အလက္</a>
                    <a href="mm-PassForBalance" class="list-group-item">ေငြသားပိုင္ဆိုင္မႈ</a>
                    <a href="mm-last-trans" class="list-group-item">ေငြသားအထုတ္အသြင္းစာရင္း</a>
                    <a href="mm-level-graph" class="list-group-item">ဆင့္ပြားစာရင္း</a>
                    <a href="mm-cash-in" class="list-group-item">ေငြသြင္းမည္</a>
                    <a href="mm-cash-out" class="list-group-item">ေငြထုတ္မည္</a>
                    <a href="mm-remit" class="list-group-item">ေငြလႊဲမည္</a>
                    <a href="mm-shopping" class="list-group-item">ေစ်းဝယ္မည္</a>
                    <a href="mm-member-topup" class="list-group-item">ဖုန္းေငြျဖည့္ကတ္ဒ္ ဝယ္ရန္</a>
                    <a href="mm-user-guide" class="list-group-item">အသံုးျပဳနည္းလမ္းညႊန္</a>
                    <a href="mm-ac-settings" class="list-group-item">ျပင္ဆင္ရန္</a>

                    
                    
                </div>
            </div>
            <!-- Content Column -->
           @show
        </div>
        <!-- /.row -->

        <hr>


        <!-- Footer -->
        @endsection
        <!-- Footer -->
@section('footer')
</div>
        <!-- /.row -->
        <hr/>
    
@parent

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

@endsection