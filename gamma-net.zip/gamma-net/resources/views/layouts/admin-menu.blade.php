@extends('layouts.navbar')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
    @parent

    <!-- Page Content -->
     <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Admin area
                    <small>Administrator Page</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index">Administrator Page</a>
                    </li>
                    <li class="active">You can control now!</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Content Row -->
         <div class="row">
            <!-- Sidebar Column -->
            <div class="col-md-3">
                <div class="list-group">
                    <a href="view-user" class="list-group-item">View User</a>
                    <a href="insert-user" class="list-group-item">Insert User</a>
                    <a href="delete-user" class="list-group-item">Delete User</a>
                    <a href="manage-userstatus" class="list-group-item">Manage User Status</a>
                    <a href="cash-inReq" class="list-group-item">Cash In Requests</a>
                    <a href="cash-outReq" class="list-group-item">Cash Out Requests</a>
                    <a href="remit-tobank" class="list-group-item">Remit to Bank</a>
                    <a href="remit-tognet" class="list-group-item">Remit to G-Net</a>
                    <a href="cash-deposit" class="list-group-item">Cash Deposit</a>
                    <a href="cash-withdrawl" class="list-group-item">Cash Withdrawl</a>
                    <a href="end-ofmonth" class="list-group-item">End of Month</a>
                    <a href="all-userannoucement" class="list-group-item">All User Annoucement</a>
                    <a href="individual-annoucement" class="list-group-item">Individual Annoucement</a>
                    <a href="change-marktype" class="list-group-item">Change Mark Type</a>
                   
                </div>
            </div>
            <!-- Content Column -->
            @show

       


        <!-- Footer -->
        @endsection
        <!-- Footer -->
@section('footer')
</div>
        <!-- /.row -->
        <hr/>
    
@parent

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

@endsection