@extends('layouts.navbar')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
    @parent

    <!-- Page Content -->
     <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Cashier area
                    <small>Cashier Page</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index">Cashier Page</a>
                    </li>
                    <li class="active">You can control cash now!</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

        <!-- Content Row -->
         <div class="row">
            <!-- Sidebar Column -->
            <div class="col-md-3">
                <div class="list-group">
                    <a href="insert-item" class="list-group-item">Insert Item</a>
                    <a href="delete-item" class="list-group-item">Delete Item</a>
                    <a href="sale-item" class="list-group-item">Sale Item</a>
                    <a href="insert-phonebill" class="list-group-item">Insert Phone Bill</a>
                    <a href="view-products" class="list-group-item">View Products</a>
                    <a href="sale-history" class="list-group-item">Sale History</a>
                    <a href="cash-inhand" class="list-group-item">Cash In hand</a>                                      
                </div>
            </div>
            <!-- Content Column -->
            @show

       


        <!-- Footer -->
        @endsection
        <!-- Footer -->
@section('footer')
</div>
        <!-- /.row -->
        <hr/>
    
@parent

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

@endsection