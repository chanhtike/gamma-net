@extends('layouts.member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
 			
 			<div class="col-md-9">
                <h2>Cash In Process Successful</h2>
                <p>Your balance will be <b>xxx</b> Ks within <b>xxx</b> minutes.</p>
                <p>Thank's for using our services</p>
            </div>

    @endsection

@section('footer')
@parent
@endsection


