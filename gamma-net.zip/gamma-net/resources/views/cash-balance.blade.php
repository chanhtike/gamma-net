@extends('layouts.member-menu')
@section('title', 'Gamma-Net')
@section('header')
@section('sidebar')
 	@parent
 			
 			<div class="col-md-9">
                <h2>Cash Balance</h2>
                <h3>Your ramaining balance is : <b> xxxxxx</b> Ks</h3>
                <h4> Thank's for using our services</h4>
            </div>

    @endsection

@section('footer')
@parent
@endsection


